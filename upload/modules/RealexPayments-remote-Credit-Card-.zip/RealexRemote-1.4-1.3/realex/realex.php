<?php

if (!defined('_CAN_LOAD_FILES_'))
	exit;

class realex extends PaymentModule 
{
	private $_html = '';
	private $_postErrors = array();	
	public $mod;
	public $realexId;
	public $sharedSecret;
	public $account;	
	public $amount;
	public $currency;
	public $cardnumber;
	public $cardname;
	public $cardtype;
	public $curr_month;
	public $curr_year;
	public $expdate;
	public $expdate_compare;
	public $secure;
	public $issueno;
	private $tab_card = array('MC','VISA','AMEX','LASER','UK Maestro');
	public $card_accepted = array();
	public $order_id;	
	public $curr_accepted;	
	public $tabError = array();		
	public $errorPaymentNumber;
	public $errorPaymentMessage;
	public $errorPayment;
	
	public function __construct()
	{
		$this->name = 'realex';
		if(version_compare(_PS_VERSION_, '1.4', '<')) 
         $this->tab = 'Payment';
		else
			$this->tab = 'payments_gateways';
			
		$this->version = '2.1';
		$this->author = 'Coccinet';
		
		$this->currencies = true;
		$this->currencies_mode = 'checkbox';
			
		$config = Configuration::getMultiple(array('REALEX_ID','SHARED_SECRET','CARD_TYPE','REALEX_ACCOUNT'));
		if (isset($config['REALEX_ID']))
			$this->realexId = $config['REALEX_ID'];
		if (isset($config['SHARED_SECRET']))
			$this->sharedSecret = $config['SHARED_SECRET'];
		if (isset($config['REALEX_ACCOUNT']))
			$this->account = $config['REALEX_ACCOUNT'];
		if (isset($config['CARD_TYPE'])){
			$this->card_accepted = explode ('-',$config['CARD_TYPE']);
			unset($this->card_accepted[array_search("", $this->card_accepted)]);
			
		}

		parent::__construct();
		
		

		$this->displayName = $this->l('Realex Remote Payment');
		$this->description = $this->l('Accepts payments by credit card');
		$this->mod = $this->l('Credit Card');
		$this->confirmUninstall = $this->l('Are you sure you want to delete your details?');
		if (!isset($this->realexId) OR !isset($this->sharedSecret) OR ($config['CARD_TYPE'])=="")
			$this->warning = $this->l('Realex ID, Shared Secret and type of accepted cards must be configured in order to use this module correctly');
		if (!sizeof(Currency::checkPaymentCurrencies($this->id)))
			$this->warning = $this->l('No currency set for this module');
	}

	//Module installation for Backoffice
	public function install()
	{
		if (!parent::install() OR !$this->registerHook('payment') OR !$this->registerHook('paymentReturn'))
			return false;
		return true;
	}
	
	//Module uninstallation for Backoffice
	public function uninstall()
	{
		if (!Configuration::deleteByName('SHARED_SECRET')
				OR !Configuration::deleteByName('REALEX_ID')
				OR !Configuration::deleteByName('CARD_TYPE')
				OR !Configuration::deleteByName('REALEX_ACCOUNT')
				OR !parent::uninstall())
			return false;
		return true;
	}	
	
	//Put the module on its place (payment) on front office
	public function hookPayment($params)
	{
		if (!$this->active)
			return ;
		if (!$this->_checkCurrency($params['cart']))
			return ;

		global $smarty;

		$smarty->assign(array(
			'this_path' => $this->_path,
			'this_path_ssl' => Tools::getHttpHost(true, true).__PS_BASE_URI__.'modules/'.$this->name.'/',
		));
		return $this->display(__FILE__, 'payment.tpl');
	}

	//The page of return after payment
	public function hookPaymentReturn($params)
	{
		if (!$this->active)
			return ;

		global $smarty;
		$state = $params['objOrder']->getCurrentState();
		if ($state == _PS_OS_PAYMENT_ OR $state == _PS_OS_OUTOFSTOCK_)
			$smarty->assign(array(
				'total_to_pay' => Tools::displayPrice($params['total_to_pay'], $params['currencyObj'], false, false),
				'status' => 'ok',
				'id_order' => $params['objOrder']->id
			));
		else
			$smarty->assign('status', 'failed');
		return $this->display(__FILE__, 'payment_return.tpl');
	}	
	
	public function getNextOrderId()
	{		
		$sql = 'SHOW TABLE STATUS FROM `'._DB_NAME_.'` LIKE "'._DB_PREFIX_.'orders"';
      $result = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);
      return $result[0]['Auto_increment'];
	}
	
	//Display the payment form
	public function execPayment($cart)
	{
		//$cookie->id_currency = intval(1);
		if (!$this->active)
			return ;
		if (!$this->_checkCurrency($cart))
			Tools::redirectLink(__PS_BASE_URI__.'order.php');
		
		if ($this->errorPaymentNumber)
			$this -> _getError();

		global $cookie, $smarty;
		
		$shop_name = Configuration::get('PS_SHOP_NAME');
		//var_dump($this->curr_accepted);exit;

		$smarty->assign(array(
			'nbProducts' => $cart->nbProducts(),
			'cust_currency' => $cookie->id_currency,
			'currency' => $this->currency['iso_code'],
			'currencies' => $this->getCurrency(),
			'total' => $cart->getOrderTotal(true, 3),
			'isoCode' => Language::getIsoById(intval($cookie->id_lang)),
			'errorPayment' => $this->errorPayment,
			'cardname' => $this->cardname,
			'cardnumber' => $this->cardnumber,
			'issueno' => $this->issueno,
			'secure' => $this->secure,
			'cardtype' => $this->cardtype,
			'card_accepted' => $this->card_accepted,
			'curr_year' => $this->curr_year,
			'curr_month' => $this->curr_month,
			'expdate' => $this->expdate,
			'this_path' => $this->_path,
			'tabError'=>$this->tabError,
			'shop_name'=>$shop_name,
			'this_path_ssl' => Tools::getHttpHost(true, true).__PS_BASE_URI__.'modules/'.$this->name.'/'
		));

		return $this->display(__FILE__, 'payment_execution.tpl');
	}
	
	//Get the information on the payment form
	public function getAuth($post)
	{
		global $cookie, $cart;		
		extract($post);		
		$this->cardtype = $cardtype;
		$currency = new Currency($cart->id_currency);
		$amount= Tools::displayPrice($cart->getOrderTotal(true, 3),$currency);
		$amount=str_replace('.','',$amount);
		$amount=str_replace(',','',$amount);
		$amount=str_replace(' ','',$amount);
		$amount=str_replace($currency->sign,'',$amount);		
		$this->amount = $amount;		
		$id_currency = Currency::getCurrency($cookie->id_currency);
		$this->currency = $id_currency['iso_code'];		
		$this->cardnumber = $cardnumber;		
		$this->issueno = $issue;		
		$this->curr_year = $year;
		$this->curr_month = $month;
		$year= substr($year,2);
		$expdate = $month.$year;
		$expdate_compare = $year.$month;
		$this->expdate = $expdate;
		$this->expdate_compare = $expdate_compare;		
		$this->secure = $secure;		
		$this->cardname = $cardname;		
		$this->_postValidationPayment($post);
		return $this->tabError;
	}

	
	
	
//////////////////////////////////////////////////////////////////////////////////////////////////////////	
////////// PRIVATE //////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////	

	//Check the fields with reguler expression
	private function _checkFields($regex, $field){
		if (preg_match($regex , $field))
			return true;		 
		 else 
			 return false;		 	
	}

//Check the form submission on back office
	private function _postValidation()
	{
		if (isset($_POST['btnSubmit']))
		{
			if (empty($_POST['realexId'])){
				$this->_postErrors[] = $this->l('Realex ID is required.');				
			}
			elseif(!empty($_POST['realexId'])){
				$checkID=$this->_checkFields("#[^a-zA-Z0-9]#", $_POST['realexId']);
				if ($checkID)
					$this->_postErrors[] = $this->l('Wrong Realex ID');
			}
			if (empty($_POST['sharedSecret']))
				$this->_postErrors[] = $this->l('Shared Secret is required.');
			elseif(!empty($_POST['sharedSecret'])){
				$checkSecret=$this->_checkFields("#[^a-zA-Z0-9]#", $_POST['sharedSecret']);
				if ($checkSecret)
					$this->_postErrors[] = $this->l('Wrong Shared Secret');
			}
			if (!empty($_POST['sharedSecret']) && $this->_checkFields("#[^a-zA-Z0-9]#", $_POST['account']))
				$this->_postErrors[] = $this->l('Wrong Account name');
		}
	}

//Module on the list on back office
	private function _displayrealex()
	{
		$this->_html .= '<img src="../modules/realex/logo_realex.jpg" style="float:left; margin-right:15px;"><b>'.$this->l('This module allows you to configure payment with Realex.').'</b><br /><br />';
	}	

	//Display the configuration form and errors of submission
	public function getContent()
	{
		$this->_html = '<h2>'.$this->displayName.'</h2>';

		if (!empty($_POST))
		{
			$this->_postValidation();
			if (!sizeof($this->_postErrors))
				$this->_postProcess();
			else
				foreach ($this->_postErrors AS $err)
					$this->_html .= '<div class="alert error">'. $err .'</div>';
		}
		else
			$this->_html .= '<br />';

		$this->_displayrealex();
		$this->_displayForm();

		return $this->_html;
	}

//Update the modules datas on backoffice
	private function _postProcess()
	{
		if (Tools::getValue('btnSubmit'))
		{
			for($i=0;$i<sizeof($this->tab_card);$i++){
				if (!empty($_POST['cardtype'.$i]) && $_POST['cardtype'.$i]!="")
					$card.= '-'.$_POST['cardtype'.$i];
			}			
			Configuration::updateValue('REALEX_ID', $_POST['realexId']);
			Configuration::updateValue('SHARED_SECRET', $_POST['sharedSecret']);
			Configuration::updateValue('REALEX_ACCOUNT', $_POST['account']);
			Configuration::updateValue('CARD_TYPE', $card);
			$this->card_accepted=explode('-',$card);
			unset($this->card_accepted[array_search("", $this->card_accepted)]);
		}
		$this->_html .= '<div class="conf confirm"><img src="../img/admin/ok.gif" alt="'.$this->l('ok').'" /> '.$this->l('Settings updated').'</div>';
	}
	
///////Configuration form on backoffice
	private function _displayForm()
	{
		$tab_iso_code = array();
		$curr_ok = Currency::getCurrencies();
		for($i=0;$i<sizeof($curr_ok);$i++){
			$tab_iso_code[$curr_ok[$i]['iso_code']]= $curr_ok[$i]['iso_code'];
		}
		for($i=0;$i<sizeof($this->tab_card);$i++){			
			if (htmlentities(Tools::getValue('cardtype'.$i), ENT_COMPAT, 'UTF-8')  OR in_array($this->tab_card[$i],$this->card_accepted)){
				$check[$i]="checked='checked'";
			}
		}		
		$this->_html .=
		'<form action="'.$_SERVER['REQUEST_URI'].'" method="post">
			<fieldset>
			<legend><img src="../img/admin/contact.gif" />'.$this->l('Contact details').'</legend>
				<table border="0" width="500" cellpadding="0" cellspacing="0" id="form">
					<tr>
						<td colspan="2">'.$this->l('Please specify your Realex information').'.<br /><br /></td>
					</tr>
					<tr>
						<td width="150" style="height: 35px;">'.$this->l('Realex merchant ID').'</td>
						<td><input type="text" name="realexId" value="'.htmlentities(Tools::getValue('realexId', $this->realexId), ENT_COMPAT, 'UTF-8').'" style="width: 300px;" /></td>
					</tr>
					<tr>
						<td width="130" style="vertical-align: top;">'.$this->l('Shared Secret').'</td>
						<td style="padding-bottom:15px;">
							<input type="password" name="sharedSecret" value="'.htmlentities(Tools::getValue('sharedSecret', $this->sharedSecret), ENT_COMPAT, 'UTF-8').'" style="width: 300px;"/>
						</td>
					</tr>
					<tr>
						<td width="130" style="vertical-align: top;">'.$this->l('Account').'</td>
						<td style="padding-bottom:15px;">
							<input type="text" name="account" value="'.htmlentities(Tools::getValue('account', $this->account), ENT_COMPAT, 'UTF-8').'" style="width: 300px;"/>
						</td>
					</tr>
					<tr>
						<td>'.$this->l('Card type accepted').'<br /><br /></td>
						<td valign="top">
							<table>';
							for($i=0;$i<sizeof($this->tab_card);$i++){
								if ((!array_key_exists("GBP",$tab_iso_code) && $this->tab_card[$i]=='UK Maestro') || (!array_key_exists("EUR",$tab_iso_code) && $this->tab_card[$i]=='LASER'))
									 $dis = "disabled='disabled'";
								$this->_html .=
								'<tr>
									<td><input type="checkbox" value="'.$this->l($this->tab_card[$i]).'" name="cardtype'.$i.'" '.$check[$i].' '.$dis.'>'.$this->tab_card[$i].'
									</td>
								</tr>';
							}
							$this->_html .='
							</table>
						</td>
					</tr>
					<tr>
						<td colspan="2" align="center">
							<input class="button" name="btnSubmit" value="'.$this->l('Update settings').'" type="submit" />
						</td>
					</tr>
				</table>
			</fieldset>
		</form>';
	}
	
	private function _postValidationPayment($post)
	{
		
		extract($post);		
		$month = date(m);
		$year = date(y);
		$date_current = $year.$month;		
		$luhn = $this->_luhnCheck($cardnumber);
		
		if (empty($cardnumber))
			$this->tabError[]=$this->l('Card Number is required');			
		elseif (strlen($cardnumber)<12  || strlen($cardnumber)>19 || $this->_checkFields("#[^0-9]#", $cardnumber))
			$this->tabError[]=$this->l('Please check your card number');
		elseif (!$luhn)
			$this->tabError[]=$this->l('The Luhn Check failed');			
		
		if (empty($cardname)){
			$this->tabError[]=$this->l('Card Name is required');
		}
		elseif(strlen($cardname)>50)
			$this->tabError[]=$this->l('The name you entered is too long');		
		
		if (empty($secure)){
			if ($cardtype != "LASER")		
				$this->tabError[]=$this->l('Security Code is required');
		}
		elseif (
			($cardtype =="AMEX" && strlen($secure) != 4) 
			|| ($cardtype =="VISA" || $cardtype =="MC" || $cardtype =="UK Maestro")  && strlen($secure) != 3
			|| ($this->_checkFields("#[^0-9]#", $secure))
		)
			$this->tabError[]=$this->l('Check your security code');
		
		if ($this->expdate_compare < $date_current)
			$this->tabError[]=$this->l('Check your expiration date');			
	}
	
///////Get the Error Payment Number send by realex
	private function _getError(){
		global $cookie;
		$lang = Language::getIsoById(intval($cookie->id_lang));
		$realexError = $this->errorPaymentNumber;
		//echo $realexError;
		//exit;
		if ($realexError == 101)
			$this->errorPayment = $this->l('The transaction has been declined by your bank.');
		elseif($realexError == 102 || $realexError == 103)
			$this->errorPayment = $this->l('The transaction has been declined by your bank. Please contact your bank.');
		elseif($realexError >= 200 AND $this->errorPaymentNumber<400)
			$this->errorPayment = $this->l('There has been a problem processing the transaction. Please try again and if the problem persists contact the merchant.');
		elseif($realexError == 501)
			$this->errorPayment = $this->l('This transaction has already been processed.');
		elseif($realexError == 509){
			if ($lang == "en")
				$this->errorPayment = $this->errorPaymentMessage;
			else
				$this->errorPayment = $this->l('Details are incorrect. Please check it and try again');
		}
		elseif($realexError == 510){
			$this->errorPayment = $this->l('That amount is greater than the max allowed');
		}
		else
			$this->errorPayment = $this->l('There has been a problem processing your transaction. Please check the card type and details are correct and try again, if the problem persists contact the merchant.');
	}

///////LUHN CHeck
	private function _luhnCheck($cardnumber) {
      $sum = 0;
    $alt = false;
    for($i = strlen($cardnumber) - 1; $i >= 0; $i--) 
    {
        if($alt)
        {
           $temp = $cardnumber[$i];
           $temp *= 2;
           $cardnumber[$i] = ($temp > 9) ? $temp = $temp - 9 : $temp;
        }
        $sum += $cardnumber[$i];
        $alt = !$alt;
    }
    return $sum % 10 == 0;
	}
	
//////Check the currency used
	private function _checkCurrency($cart)
	{
		$currency_order = new Currency(intval($cart->id_currency));
		$currencies_module = $this->getCurrency();
		$currency_default = Configuration::get('PS_CURRENCY_DEFAULT');
		
		if (is_array($currencies_module))
			foreach ($currencies_module AS $currency_module)
				if ($currency_order->id == $currency_module['id_currency'])
					return true;
	}
}
