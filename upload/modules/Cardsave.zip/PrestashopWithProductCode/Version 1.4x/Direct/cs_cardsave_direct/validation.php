<?php
session_start();

include(dirname(__FILE__). '/../../config/config.inc.php');
include(dirname(__FILE__). '/../../init.php');
include(dirname(__FILE__). '/cs_cardsave_direct.php');
require_once ("ThePaymentGateway/PaymentSystem.php");

$gateway_id = Configuration::get('CARDSAVE_DIRECT_GATEWAY_ID');
$gateway_password = Configuration::get('CARDSAVE_DIRECT_PASSWORD');
$gateway_domain = Configuration::get('CARDSAVE_DIRECT_PROCESSOR_DOMAIN');
$gateway_port = Configuration::get('CARDSAVE_DIRECT_PROCESSOR_PORT');
$gateway_transtype = $_POST['gateway_transtype'];

$card_name = $_POST['card_name'];
$card_number = $_POST['card_number'];
$card_cv2 = $_POST['card_cv2'];

$card_issue = $_POST['card_issue'];

if ($card_issue != "") {
	$card_issue = new NullableInt($card_issue);
} else {
	$card_issue = NULL;
}

$card_startdate_month = $_POST['card_startdate_Month'];
$card_startdate_year = substr($_POST['card_startdate_Year'] , 2, 2);
$card_expdate_month = $_POST['card_expdate_Month'];
$card_expdate_year = substr($_POST['card_expdate_Year'] , 2, 2);

$cart_id = $_POST['cart_id'];
$order_number = date('YmdHis')."-".$cart_id;

$order_amount = $_POST['order_amount'];
$order_address1 = $_POST['order_address1'];
$order_address2 = NULL;
$order_address3 = NULL;
$order_address4 = NULL;
$order_city = $_POST['order_city'];
$order_county = NULL;
$order_postcode = $_POST['order_postcode'];
$order_country = "";

$order_phone = $_POST['order_phone'];
$order_email = $_POST['order_email'];
$order_ip = $_POST['order_ip'];

$order_currency = 826;

$rgeplRequestGatewayEntryPointList = new RequestGatewayEntryPointList();

$rgeplRequestGatewayEntryPointList->add("https://gw1.".$gateway_domain.":".$gateway_port, 100, 2);
$rgeplRequestGatewayEntryPointList->add("https://gw2.".$gateway_domain.":".$gateway_port, 200, 2);
$rgeplRequestGatewayEntryPointList->add("https://gw3.".$gateway_domain.":".$gateway_port, 300, 2);

$mdMerchantDetails = new MerchantDetails($gateway_id, $gateway_password);

$ttTransactionType = new NullableTRANSACTION_TYPE(TRANSACTION_TYPE::SALE);
$mdMessageDetails = new MessageDetails($ttTransactionType);

$boEchoCardType = new NullableBool(true);
$boEchoAmountReceived = new NullableBool(true);
$boEchoAVSCheckResult = new NullableBool(true);
$boEchoCV2CheckResult = new NullableBool(true);
$boThreeDSecureOverridePolicy = new NullableBool(true);
$nDuplicateDelay = new NullableInt(60);
$tcTransactionControl = new TransactionControl($boEchoCardType, $boEchoAVSCheckResult, $boEchoCV2CheckResult, $boEchoAmountReceived, $nDuplicateDelay, "",  "", $boThreeDSecureOverridePolicy,  "",  null, null);

$nAmount = new NullableInt($order_amount);
$nCurrencyCode = new NullableInt($order_currency);
$nDeviceCategory = new NullableInt(0);
$tdsbdThreeDSecureBrowserDetails = new ThreeDSecureBrowserDetails($nDeviceCategory, "*/*",  $_SERVER["HTTP_USER_AGENT"]);
$tdTransactionDetails = new TransactionDetails($mdMessageDetails, $nAmount, $nCurrencyCode, $order_number, $OrderDescription, $tcTransactionControl, $tdsbdThreeDSecureBrowserDetails);

if ($card_expdate_month != "") {
	$nExpiryDateMonth = new NullableInt($card_expdate_month);
} else {
	$nExpiryDateMonth = null;
}
if ($card_expdate_year != "") {
	$nExpiryDateYear = new NullableInt($card_expdate_year);
} else {
	$nExpiryDateYear = null;
}
$ccdExpiryDate = new CreditCardDate($nExpiryDateMonth, $nExpiryDateYear);

if ($card_startdate_month != "") {
	$nStartDateMonth = new NullableInt($card_startdate_month);
} else {
	$nStartDateMonth = null;
}
if ($card_startdate_year != "") {
	$nStartDateYear = new NullableInt($card_startdate_year);
} else {
	$nStartDateYear = null;
}
$ccdStartDate = new CreditCardDate($nStartDateMonth, $nStartDateYear);
$cdCardDetails = new CardDetails($card_name, $card_number, $ccdExpiryDate, $ccdStartDate, $IssueNumber, $card_cv2);

if ($order_country != "" && $order_country != -1) {
	$nCountryCode = new NullableInt($order_country);
} else {
	$nCountryCode = null;
}
$adBillingAddress = new AddressDetails($order_address1, $order_address2, $order_address3, $order_address4, $order_city, $order_county, $order_postcode, $nCountryCode);
$cdCustomerDetails = new CustomerDetails($adBillingAddress, $order_email, $order_phone, $_SERVER["REMOTE_ADDR"]);

$cdtCardDetailsTransaction = new CardDetailsTransaction($rgeplRequestGatewayEntryPointList, 1, null, $mdMerchantDetails, $tdTransactionDetails, $cdCardDetails, $cdCustomerDetails, "Some data to be passed out");
$boTransactionProcessed = $cdtCardDetailsTransaction->processTransaction($goGatewayOutput, $tomTransactionOutputMessage);

if ($boTransactionProcessed == false)
{
	// could not communicate with the payment gateway 
	$NextFormMode = "PAYMENT_FORM";
	$Message = "Couldn't communicate with payment gateway";
}
else
{
	switch ($goGatewayOutput->getStatusCode())
	{
		case 0:
			// status code of 0 - means transaction successful 
			$NextFormMode = "RESULTS";			
			$AuthCode = $tomTransactionOutputMessage->getAuthCode();
			$Message .= "PAYMENT SUCCESSFUL <br> ";
			$Message .= "MMS Order ID: " . $order_number . " <br> ";
			$Message .=	"Auth Code: " . $tomTransactionOutputMessage->getAuthCode() . " <br> ";
			$Message .= "Cross Reference: " . $tomTransactionOutputMessage->getCrossReference() . " <br> ";
			$Message .=	"Address Check: " . $tomTransactionOutputMessage->getAddressNumericCheckResult()->getValue() . " <br> ";
			$Message .=	"Postcode Check: " . $tomTransactionOutputMessage->getPostCodeCheckResult()->getValue() . " <br> ";
			$Message .=	"CV2 Check: " . $tomTransactionOutputMessage->getCV2CheckResult()->getValue() . " <br> ";
			$Message .=	"3D Secure Result: " . $tomTransactionOutputMessage->getThreeDSecureAuthenticationCheckResult()->getValue();
			
			$TransactionSuccessful = true;
			break;
		case 3:			
			// status code of 3 - means 3D Secure authentication required 
			$NextFormMode = "THREE_D_SECURE";
			$PaREQ = $tomTransactionOutputMessage->getThreeDSecureOutputData()->getPaREQ();
			$CrossReference = $tomTransactionOutputMessage->getCrossReference();
			$FormAction = $tomTransactionOutputMessage->getThreeDSecureOutputData()->getACSURL();
			break;
		case 4:
			// status code of 4 - means transaction referred 
			$NextFormMode = "RESULTS";
			$Payment_Error = $goGatewayOutput->getMessage();
			$Message =	"CARD REFERRED <br> ";
			$Message .= "MMS Order ID: " . $order_number . " <br> ";
			$Message .=	"Message: " . $goGatewayOutput->getMessage() . " <br> ";
			$Message .= "Cross Reference: " . $tomTransactionOutputMessage->getCrossReference() . " <br> ";
			$Message .=	"Address Check: " . $tomTransactionOutputMessage->getAddressNumericCheckResult()->getValue() . " <br> ";
			$Message .=	"Postcode Check: " . $tomTransactionOutputMessage->getPostCodeCheckResult()->getValue() . " <br> ";
			$Message .=	"CV2 Check: " . $tomTransactionOutputMessage->getCV2CheckResult()->getValue() . " <br> ";
			$Message .=	"3D Secure Result: " . $tomTransactionOutputMessage->getThreeDSecureAuthenticationCheckResult()->getValue();
			$TransactionSuccessful = false;
			break;
		case 5:
			// status code of 5 - means transaction declined 
			$NextFormMode = "RESULTS";
			$Payment_Error = $goGatewayOutput->getMessage();
			$Message =	"CARD DECLINED <br> ";
			$Message .= "MMS Order ID: " . $order_number . " <br> ";
			$Message .=	"Message: " . $goGatewayOutput->getMessage() . " <br> ";
			$Message .= "Cross Reference: " . $tomTransactionOutputMessage->getCrossReference() . " <br> ";
			$Message .=	"Address Check: " . $tomTransactionOutputMessage->getAddressNumericCheckResult()->getValue() . " <br> ";
			$Message .=	"Postcode Check: " . $tomTransactionOutputMessage->getPostCodeCheckResult()->getValue() . " <br> ";
			$Message .=	"CV2 Check: " . $tomTransactionOutputMessage->getCV2CheckResult()->getValue() . " <br> ";
			$Message .=	"3D Secure Result: " . $tomTransactionOutputMessage->getThreeDSecureAuthenticationCheckResult()->getValue();
			
			$TransactionSuccessful = false;
			break;
		case 20:
			// status code of 20 - means duplicate transaction 
			$NextFormMode = "RESULTS";
			$Message = $goGatewayOutput->getMessage();
			if ($goGatewayOutput->getPreviousTransactionResult()->getStatusCode()->getValue() == 0)
			{
				$TransactionSuccessful = true;
			}
			else
			{
				$TransactionSuccessful = false;
			}
			$PreviousTransactionMessage = $goGatewayOutput->getPreviousTransactionResult()->getMessage();
			$Payment_Error = $PreviousTransactionMessage;
			$DuplicateTransaction = true;
			break;
		case 30:
			// status code of 30 - means an error occurred 
			$NextFormMode = "PAYMENT_FORM";
			$Message = $goGatewayOutput->getMessage();
			
			if ($goGatewayOutput->getErrorMessages()->getCount() > 0)
			{
				for ($LoopIndex = 0; $LoopIndex < $goGatewayOutput->getErrorMessages()->getCount(); $LoopIndex++)
				{
					$Message = $Message."<br />".$goGatewayOutput->getErrorMessages()->getAt($LoopIndex);
				}
				
				$TransactionSuccessful = false;
			}
			
			$Payment_Error = $Message;
			break;
		default:
			// unhandled status code  
			$NextFormMode = "PAYMENT_FORM";
			$Message = $goGatewayOutput->getMessage();
			$Payment_Error = $Message;
			break;
	}
}

if ($NextFormMode == "THREE_D_SECURE") {
	
	$ThreeDUrl = "http://" . $_SERVER['HTTP_HOST'] . __PS_BASE_URI__ . "modules/cs_cardsave_direct/validation_3ds.php";
	
	$_SESSION['order_amount'] = $order_amount;
	$_SESSION['cart_id'] = $cart_id;
	$_SESSION['order_id'] = $order_number;
	
	echo '<html>
			<body onload="document.Form.submit();">
				<form name="Form" action="'. $FormAction .'" method="post">
					<input name="PaReq" type="hidden" value="'. $PaREQ .'" />
					<input name="MD" type="hidden" value="'. $CrossReference .'" />
					<input name="TermUrl" type="hidden" value="'. $ThreeDUrl .'" />
				</form>
			</body>
		</html>';
	
} else {
	$cart = new Cart($cart_id);
	if (!Validate::isLoadedObject($cart))
	{
		Logger::addLog('Cart loading failed for cart '.$cart_id, 4);
		echo 'Cart loading failed for cart' . $cart_id;
		exit;
	}

	$customer = new Customer((int)$cart->id_customer);
	
	$cs_cardsave_direct = new cs_cardsave_direct();
	
	if ($TransactionSuccessful) {
		$cs_cardsave_direct->validateOrder((int)$cart->id, Configuration::get('PS_OS_PAYMENT'), $order_amount/100, "CardSave Direct", $Message, NULL, NULL, false, $customer->secure_key);	
		Tools::redirect('order-confirmation.php?id_module='.(int)$cs_cardsave_direct->id.'&id_cart='.(int)$cart->id.'&key='.$customer->secure_key.'&ac='.$AuthCode.'&orderid='.$cs_cardsave_direct->currentOrder);
	} else {
		$cs_cardsave_direct->validateOrder((int)$cart->id, Configuration::get('PS_OS_ERROR'), $order_amount/100, "CardSave Direct", $Message, NULL, NULL, false, $customer->secure_key);
		Tools::redirect('order-confirmation.php?id_module='.(int)$cs_cardsave_direct->id.'&id_cart='.(int)$cart->id.'&key='.$customer->secure_key.'&err='.$Payment_Error.'&orderid='.$cs_cardsave_direct->currentOrder);
	}
}