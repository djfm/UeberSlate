<?php
/*
This file is part of the Prestashop CardSave Re-Directed Payment Module
See cs_cardsave.php for Licensing and support info.
File Last Modified: 28/06/2011 - By Alistair Richardson - CardSave Online
*/

include(dirname(__FILE__) . '/../../config/config.inc.php');
include(dirname(__FILE__) . '/cs_cardsave.php');

if(intval(Configuration::get('PS_REWRITING_SETTINGS')) === 1)
    $rewrited_url = __PS_BASE_URI__;

    function addStringToStringList($szExistingStringList, $szStringToAdd)
		{
			$szReturnString = "";
			$szCommaString = "";

			if (strlen($szStringToAdd) == 0)
			{
				$szReturnString = $szExistingStringList;
			}
			else
			{
				if (strlen($szExistingStringList) != 0)
				{
					$szCommaString = ", ";
				}
				$szReturnString = $szExistingStringList.$szCommaString.$szStringToAdd;
			}

			return ($szReturnString);
		}
		
		$szHashDigest = "";
		$szOutputMessage = "";
		$boErrorOccurred = false;
		$nStatusCode = 30;
		$szMessage = "";
		$nPreviousStatusCode = 0;
		$szPreviousMessage = "";
		$szCrossReference = "";
		$nAmount = 0;
		$nCurrencyCode = 0;
		$szOrderID = "";
		$szTransactionType= "";
		$szTransactionDateTime = "";
		$szOrderDescription = "";
		$szCustomerName = "";
		$szAddress1 = "";
		$szAddress2 = "";
		$szAddress3 = "";
		$szAddress4 = "";
		$szCity = "";
		$szState = "";
		$szPostCode = "";
		$nCountryCode = "";

		try
			{
				// hash digest
				if (isset($_POST["HashDigest"]))
				{
					$szHashDigest = $_POST["HashDigest"];
				}

				// transaction status code
				if (!isset($_POST["StatusCode"]))
				{
					$szOutputMessage = addStringToStringList($szOutputMessage, "Expected variable [StatusCode] not received");
					$boErrorOccurred = true;
				}
				else
				{
					if ($_POST["StatusCode"] == "")
					{
						$nStatusCode = null;
					}
					else
					{
						$nStatusCode = intval($_POST["StatusCode"]);
					}
				}
				// transaction message
				if (!isset($_POST["Message"]))
				{
					$szOutputMessage = addStringToStringList($szOutputMessage, "Expected variable [Message] not received");
					$boErrorOccurred = true;
				}
				else
				{
					$szMessage = $_POST["Message"];
				}
				// status code of original transaction if this transaction was deemed a duplicate
				if (!isset($_POST["PreviousStatusCode"]))
				{
					$szOutputMessage = addStringToStringList($szOutputMessage, "Expected variable [PreviousStatusCode] not received");
					$boErrorOccurred = true;
				}
				else
				{
					if ($_POST["PreviousStatusCode"] == "")
					{
						$nPreviousStatusCode = null;
					}
					else
					{
						$nPreviousStatusCode = intval($_POST["PreviousStatusCode"]);
					}
				}
				// status code of original transaction if this transaction was deemed a duplicate
				if (!isset($_POST["PreviousMessage"]))
				{
					$szOutputMessage = addStringToStringList($szOutputMessage, "Expected variable [PreviousMessage] not received");
					$boErrorOccurred = true;
				}
				else
				{
					$szPreviousMessage = $_POST["PreviousMessage"];
				}
				// cross reference of transaction
				if (!isset($_POST["CrossReference"]))
				{
					$szOutputMessage = addStringToStringList($szOutputMessage, "Expected variable [CrossReference] not received");
					$boErrorOccurred = true;
				}
				else
				{
					$szCrossReference = $_POST["CrossReference"];
				}
				// amount (same as value passed into payment form - echoed back out by payment form)
				if (!isset($_POST["Amount"]))
				{
					$szOutputMessage = addStringToStringList($szOutputMessage, "Expected variable [Amount] not received");
					$boErrorOccurred = true;
				}
				else
				{
					if ($_POST["Amount"] == null)
					{
						$nAmount = null;
					}
					else
					{
						$nAmount = (float) floatval($_POST["Amount"]);
					}
				}
				// currency code (same as value passed into payment form - echoed back out by payment form)
				if (!isset($_POST["CurrencyCode"]))
				{
					$szOutputMessage = addStringToStringList($szOutputMessage, "Expected variable [CurrencyCode] not received");
					$boErrorOccurred = true;
				}
				else
				{
					if ($_POST["CurrencyCode"] == null)
					{
						$nCurrencyCode = null;
					}
					else
					{
						$nCurrencyCode = intval($_POST["CurrencyCode"]);
					}
				}
				// order ID (same as value passed into payment form - echoed back out by payment form)
				if (!isset($_POST["OrderID"]))
				{
					$szOutputMessage = addStringToStringList($szOutputMessage, "Expected variable [OrderID] not received");
					$boErrorOccurred = true;
				}
				else
				{
          $szOrderID = substr($_POST["OrderID"], strpos($_POST["OrderID"],"~") + 1);
				}
				// transaction type (same as value passed into payment form - echoed back out by payment form)
				if (!isset($_POST["TransactionType"]))
				{
					$szOutputMessage = addStringToStringList($szOutputMessage, "Expected variable [TransactionType] not received");
					$boErrorOccurred = true;
				}
				else
				{
					$szTransactionType = $_POST["TransactionType"];
				}
				// transaction date/time (same as value passed into payment form - echoed back out by payment form)
				if (!isset($_POST["TransactionDateTime"]))
				{
					$szOutputMessage = addStringToStringList($szOutputMessage, "Expected variable [TransactionDateTime] not received");
					$boErrorOccurred = true;
				}
				else
				{
					$szTransactionDateTime = $_POST["TransactionDateTime"];
				}
				// order description (same as value passed into payment form - echoed back out by payment form)
				if (!isset($_POST["OrderDescription"]))
				{
					$szOutputMessage = addStringToStringList($szOutputMessage, "Expected variable [OrderDescription] not received");
					$boErrorOccurred = true;
				}
				else
				{
					$szOrderDescription = $_POST["OrderDescription"];
				}
				// customer name (not necessarily the same as value passed into payment form - as the customer can change it on the form)
				if (!isset($_POST["CustomerName"]))
				{
					$szOutputMessage = addStringToStringList($szOutputMessage, "Expected variable [CustomerName] not received");
					$boErrorOccurred = true;
				}
				else
				{
					$szCustomerName = $_POST["CustomerName"];
				}
				// address1 (not necessarily the same as value passed into payment form - as the customer can change it on the form)
				if (!isset($_POST["Address1"]))
				{
					$szOutputMessage = addStringToStringList($szOutputMessage, "Expected variable [Address1] not received");
					$boErrorOccurred = true;
				}
				else
				{
					$szAddress1 = $_POST["Address1"];
				}
				// address2 (not necessarily the same as value passed into payment form - as the customer can change it on the form)
				if (!isset($_POST["Address2"]))
				{
					$szOutputMessage = addStringToStringList($szOutputMessage, "Expected variable [Address2] not received");
					$boErrorOccurred = true;
				}
				else
				{
					$szAddress2 = $_POST["Address2"];
				}
				// address3 (not necessarily the same as value passed into payment form - as the customer can change it on the form)
				if (!isset($_POST["Address3"]))
				{
					$szOutputMessage = addStringToStringList($szOutputMessage, "Expected variable [Address3] not received");
					$boErrorOccurred = true;
				}
				else
				{
					$szAddress3 = $_POST["Address3"];
				}
				// address4 (not necessarily the same as value passed into payment form - as the customer can change it on the form)
				if (!isset($_POST["Address4"]))
				{
					$szOutputMessage = addStringToStringList($szOutputMessage, "Expected variable [Address4] not received");
					$boErrorOccurred = true;
				}
				else
				{
					$szAddress4 = $_POST["Address4"];
				}
				// city (not necessarily the same as value passed into payment form - as the customer can change it on the form)
				if (!isset($_POST["City"]))
				{
					$szOutputMessage = addStringToStringList($szOutputMessage, "Expected variable [City] not received");
					$boErrorOccurred = true;
				}
				else
				{
					$szCity = $_POST["City"];
				}
				// state (not necessarily the same as value passed into payment form - as the customer can change it on the form)
				if (!isset($_POST["State"]))
				{
					$szOutputMessage = addStringToStringList($szOutputMessage, "Expected variable [State] not received");
					$boErrorOccurred = true;
				}
				else
				{
					$szState = $_POST["State"];
				}
				// post code (not necessarily the same as value passed into payment form - as the customer can change it on the form)
				if (!isset($_POST["PostCode"]))
				{
					$szOutputMessage = addStringToStringList($szOutputMessage, "Expected variable [PostCode] not received");
					$boErrorOccurred = true;
				}
				else
				{
					$szPostCode = $_POST["PostCode"];
				}
				// country code (not necessarily the same as value passed into payment form - as the customer can change it on the form)
				if (!isset($_POST["CountryCode"]))
				{
					$szOutputMessage = addStringToStringList($szOutputMessage, "Expected variable [CountryCode] not received");
					$boErrorOccurred = true;
				}
				else
				{
					if ($_POST["CountryCode"] == "")
					{
						$nCountryCode = null;
					}
					else
					{
						$nCountryCode = intval($_POST["CountryCode"]);
					}
				}
			}
		catch (Exception $e)
		{
			$boErrorOccurred = true;
			$szOutputMessage = "Error";
			if (!isset($_POST["Message"]))
			{
				$szOutputMessage = $_POST["Message"];
			}
		}
		
	// Open the order
    $cardsave = new cs_cardsave();
    $cart = new Cart($szOrderID);	
	$customer = new Customer((int)$cart->id_customer);

    // Format payment amount correctly
    //$orderTotal = formatAmount($nAmount, true);	
	
	// The nOutputProcessedOK should return 0 except if there has been an error talking to the gateway or updating the website order system.
	// Any other process status shown to the gateway will prompt the gateway to send an email to the merchant stating the error.
	// The customer will also be shown a message on the hosted payment form detailing the error and will not return to the merchants website.
	$nOutputProcessedOK = 0;
	
	if (is_null($nStatusCode))
	{
		$nOutputProcessedOK = 30;		
	}
	
	if ($boErrorOccurred == true)
	{
		$nOutputProcessedOK = 30;
	}
	
	function createhash($PreSharedKey,$Password) { 
		$str="PreSharedKey=" . $PreSharedKey;
		$str=$str . '&MerchantID=' . $_POST["MerchantID"];
		$str=$str . '&Password=' . $Password;
		$str=$str . '&StatusCode=' . $_POST["StatusCode"];
		$str=$str . '&Message=' . $_POST["Message"];
		$str=$str . '&PreviousStatusCode=' . $_POST["PreviousStatusCode"];
		$str=$str . '&PreviousMessage=' . $_POST["PreviousMessage"];
		$str=$str . '&CrossReference=' . $_POST["CrossReference"];
		$str=$str . '&Amount=' . $_POST["Amount"];
		$str=$str . '&CurrencyCode=' . $_POST["CurrencyCode"];
		$str=$str . '&OrderID=' . $_POST["OrderID"];
		$str=$str . '&TransactionType=' . $_POST["TransactionType"];
		$str=$str . '&TransactionDateTime=' . $_POST["TransactionDateTime"];
		$str=$str . '&OrderDescription=' . $_POST["OrderDescription"];
		$str=$str . '&CustomerName=' . $_POST["CustomerName"];
		$str=$str . '&Address1=' . $_POST["Address1"];
		$str=$str . '&Address2=' . $_POST["Address2"];
		$str=$str . '&Address3=' . $_POST["Address3"];
		$str=$str . '&Address4=' . $_POST["Address4"];
		$str=$str . '&City=' . $_POST["City"];
		$str=$str . '&State=' . $_POST["State"];
		$str=$str . '&PostCode=' . $_POST["PostCode"];
		$str=$str . '&CountryCode=' . $_POST["CountryCode"];
		return sha1($str);
	}
	
	// Check the passed HashDigest against our own to check the values passed are legitimate.
	$str1 = $_POST["HashDigest"];
	$hashcode = createhash(Configuration::get('CS_CARDSAVE_PSK'),Configuration::get('CS_CARDSAVE_GATEWAYPASS'));
	if ($hashcode != $str1) {
		$nOutputProcessedOK = 30; 
		$szOutputMessage = "Hashes did not match";
	} 

	// *********************************************************************************************************
	// You should put your code that does any post transaction tasks
	// (e.g. updates the order object, sends the customer an email etc) in this section
	// *********************************************************************************************************
	if ($nOutputProcessedOK != 30)
		{	
			$nOutputProcessedOK = 0;
			// Alter this line once you've implemented the code.
			$szOutputMessage = $szMessage;
			try
			{
				switch ($nStatusCode)
				{
					// transaction authorised
					case 0:
						$orderState =  _PS_OS_PAYMENT_;
						break;
					// card referred (treat as decline)
					case 4:
						$orderState =  _PS_OS_ERROR_;
						break;
					// transaction declined
					case 5:
						$orderState =  _PS_OS_ERROR_;
						break;
					// duplicate transaction
					case 20:
						// need to look at the previous status code to see if the
						// transaction was successful
						if ($nPreviousStatusCode == 0)
						{
							$orderState =  _PS_OS_PAYMENT_;
						}
						else
						{
							$orderState =  _PS_OS_ERROR_;
						}
						break;
					// error occurred
					case 30:
						$orderState =  _PS_OS_ERROR_;
						break;
					default:
						$orderState =  _PS_OS_ERROR_;
						break;
				}

				$db = Db::getInstance();
				
				//Get order total
				//$csquery = 'SELECT total_paid FROM '._DB_PREFIX_.'orders WHERE id_cart = ' . $szOrderID;
				//$queryresult = $db->getRow($csquery);
				//$total_paid3 = (string) $queryresult["total_paid"];
				//$total_paid2 = number_format($total_paid3,2,'.','');
				
				$nAmount = (float) number_format($nAmount/100.00, 2, '.', '');

				//Get order currency conversion rate
				//$csquery2 = 'SELECT conversion_rate FROM '._DB_PREFIX_.'currency WHERE id_currency = ' . $currencyid;
				//echo $csquery2."<br><br>";
				//$queryresult2 = $db->getRow($csquery2);
				//$conversion_rate = (float) number_format(floatval($queryresult2["conversion_rate"]), 6, '.', '');
				//echo "conversion_rate=".$conversion_rate."<br><br>";				
				//echo "nAmount=".$nAmount."<br><br>";			
				//if (number_format($conversion_rate,2, '.','') != 1.00) {
				//	$orderTotal = (float) number_format($nAmount * $conversion_rate, 2, '.', '');
				//	echo "converting - ".$nAmount." * ".$conversion_rate."<br><br>";
				//	echo "orderTotal=".$orderTotal."<br><br>";
				//} else {
					//$orderTotal = (float) $nAmount;
					//echo "no conversion needed<br><br>";
					//echo "orderTotal=".$orderTotal."<br><br>";
				//}
							
				// Update order
				$cardsave->validateOrder($szOrderID, $orderState, $nAmount, $cardsave->displayName, $szMessage, NULL, NULL, false, $customer->secure_key);
				//echo "cardsave->validateOrder(".$szOrderID.", ".$orderState.", ".$total_paid.", ".$cardsave->displayName.", ".$szMessage.")<br><br>";
			}
			catch (Exception $e)
			{
				$nOutputProcessedOK = 30;
				$szOutputMessage = "Error updating website system, please ask the developer to check code";
			}
        }

	if ($nOutputProcessedOK != 0 &&
		$szOutputMessage == "")
	{
		$szOutputMessage = "Unknown error";
	}

	// output the status code and message letting the payment form
	// know whether the transaction result was processed successfully
	echo("StatusCode=".$nOutputProcessedOK."&Message=".$szOutputMessage);	 
?>