$(document).ready(function(){
alert ("truc");
})