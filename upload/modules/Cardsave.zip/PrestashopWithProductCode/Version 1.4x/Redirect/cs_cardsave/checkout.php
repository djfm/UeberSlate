<?php
/*
This file is part of the Prestashop CardSave Re-Directed Payment Module
See cs_cardsave.php for Licensing and support info.
File Last Modified: 07/12/2010 - By Alistair Richardson - CardSave Online
*/

include(dirname(__FILE__).'/../../config/config.inc.php');
include(dirname(__FILE__) . '/cs_cardsave.php');

if(intval(Configuration::get('PS_REWRITING_SETTINGS')) === 1)
    $rewrited_url = __PS_BASE_URI__;

include(dirname(__FILE__).'/../../header.php');

$cardsave = new cs_cardsave();

// Only allow certain parameters to be passed through
$valid_params = array('cs_checksum', 'cs_payment_amount', 'cs_currency_code', 'cs_merchant_reference', 'cs_email', 'cs_cardholder_name', 'cs_houseno', 'cs_postcode', 'cs_success_url', 'cs_failure_url', 'cs_success_redirect_url', 'cs_failure_redirect_url', 'cs_return_url', 'cs_payment_amount', 'cs_currency_code', 'cs_merchant_reference');

// Grab the acceptable parameters and filter to prevent XSS
$parameters = array();
foreach ($valid_params as $param_name)
  if (array_key_exists($param_name, $_POST))
      $parameters[$param_name] = htmlspecialchars($_POST[$param_name]);

// Setup the query_string to pass paramters to the iframe
$query_string = "?";

foreach ($parameters as $param => $value)
  $query_string .= urlencode($param) . "=" . urlencode($value) . "&";

// Hide the sidebars
$html  = '<style type="text/css">.column {width:0px !important; display:none;}' .
         '#center_column {width:100%;}' .
         'iframe {border:none;}</style>';

// Draw the iframe
$html .= '<iframe id="cs_cardsave_IFRAME" height="700px" width="100%" border="0px" src="modules/cardsave/redirect.php' . $query_string . '"></iframe>';
echo($html);

include(dirname(__FILE__).'/../../footer.php');
?>