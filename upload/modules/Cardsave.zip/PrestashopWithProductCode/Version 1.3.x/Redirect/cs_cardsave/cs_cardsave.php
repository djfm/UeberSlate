<?php
/*
Prestashop Cardsave Re-Directed Payment Module
Copyright (C) 2010 Modacs Limited trading as Cardsave.
Support: support@cardsave.net

This program is free software: you can redistribute it and/or modify it under the terms
of the GNU General Public License as published by the Free Software Foundation, either
version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
See the GNU General Public License for more details. You should have received a copy of the
GNU General Public License along with this program. If not, see <http://www.gnu.org/licenses/>.

File Last Modified: 07/12/2010 - By Alistair Richardson - Cardsave Online
*/

// Helper functions
function parseBoolString($boolString) {
  if (!$boolString || (strcasecmp($boolString, "false") == 0) || $boolString == "0")
    return False;
  else
    return True;
}
    
function formatAmount($amount, $minorUnits) { 
  if (parseBoolString($minorUnits))
    $amount = $amount / 100;

  return floatval($amount);
}

function currencySymbol($currencyCode) {
  switch ($currencyCode) {
  case "GBP": 
    return "&pound;";
    break;
  case "USD": 
    return "$";
    break;
  case "EUR": 
    return "&euro;";
    break;
  default:
    return htmlentities($currencyCode);
    break;
  }
}
     

function checkParams($params) {
  if ((empty($params)) || (!array_key_exists('cs_merchant_reference', $params)) || (!array_key_exists('cs_payment_amount', $params)))
    return false;
  else
    return true;
}

function checkChecksum($secretKey, $amount, $currencyCode, $merchantRef, $cardsaveRef, $cardsaveChecksum) {
  if (empty($secretKey))
    return array(true, "checksum ignored, no secretkey");
  else {
    if (empty($cardsaveChecksum))
      return array(false, "checksum expected but missing (check secret key)");
    else {
      $checksum = sha1($amount . $currencyCode . $merchantRef . $cardsaveRef . $secretKey);
      if ($checksum != $cardsaveChecksum)
	return array(false, "checksum mismatch (check secret key)");
      else
	return array(true, "checksum matched");
    }
  }
}

// Cardsave payment module class
class cs_cardsave extends PaymentModule {
  public function __construct() {
    $this->name = "cs_cardsave";
    $this->tab = "Payment";
    $this->version = "1.4";
	$this->author = "CardSave Online";
	$this->module_key = "1e631b52ed3d1572df477b9ce182ccf8";

    $this->currencies = true;
    $this->currencies_mode = 'radio'; 
    parent::__construct(); 

    $this->displayName = $this->l('Cardsave');
    $this->description = $this->l('Process transactions through the Cardsave gateway.');
    $this->confirmUninstall = $this->l('Are you sure?');
  }

  public function install() {
    if (parent::install() && Configuration::updateValue('CS_CARDSAVE_GATEWAYID', 'changeme') && Configuration::updateValue('CS_CARDSAVE_GATEWAYPASS', 'changeme') &&
	Configuration::updateValue('CS_CARDSAVE_PSK', '') && Configuration::updateValue('CS_CARDSAVE_DEBUG', '') &&
	$this->registerHook('payment') && $this->registerHook('paymentReturn'))
      return true;
    else
      return false;
  }
  
  public function uninstall() {
    if (Configuration::deleteByName('CS_CARDSAVE_GATEWAYID') && Configuration::deleteByName('CS_CARDSAVE_GATEWAYPASS') &&
	Configuration::deleteByName('CS_CARDSAVE_PSK') && Configuration::deleteByName('CS_CARDSAVE_DEBUG') && 
	parent::uninstall())
      return true;
    else
      return false;
  }

  private function getSetting($name) {
    if (array_key_exists($name, $_POST))
      return $_POST[$name];
    else if (Configuration::get($name))
      return Configuration::get($name);
  }      

  private function validateTrueFalseString($value) {
    if ($value == "True" || $value == "False")
      return $value;
  }

  private function trueFalseOption($name, $label, $trueLabel = "True" , $falseLabel = "False") {
    if ($this->getSetting($name) == 'True') {
      $trueSelected = ' selected';
      $falseSelected = '';
    }
    else {
      $trueSelected = '';
      $falseSelected = ' selected';
    }

    $html = '<label>' . $this->l($label) . '</label><div class="margin-form"><select name="' . $name . '">' .
      '<option' . $trueSelected . ' value="True">' . $this->l($trueLabel) . '</option>' .
      '<option' . $falseSelected . ' value="False">' . $this->l($falseLabel) . '</option>' .
      '</select></div>';

    return $html;
  }

  public function getContent() {
    $this->_html .= '<h2>CardSave</h2>';

    // Validate + save their input
    $errors = "";
    if (isset($_POST['cs_cardsave_SUBMIT'])) {
      // Prestashop's pSQL prevents XSS and SQL injection for us using the pSQL function :)
      if (empty($_POST['CS_CARDSAVE_GATEWAYID']))
	$errors .= '<li><b>' . $this->l('Gateway ID') . '</b> - ' . 
	  $this->l('The Gateway ID field can\'t be left blank. Please check the correct value with Cardsave if you\'re unsure.') . '</li>';
      else
	  
	Configuration::updateValue('CS_CARDSAVE_GATEWAYID', $_POST['CS_CARDSAVE_GATEWAYID']);
	Configuration::updateValue('CS_CARDSAVE_GATEWAYPASS', $_POST['CS_CARDSAVE_GATEWAYPASS']);

    Configuration::updateValue('CS_CARDSAVE_PSK', $_POST['CS_CARDSAVE_PSK']);
	Configuration::updateValue('CS_CARDSAVE_DEBUG', $_POST['CS_CARDSAVE_DEBUG']);

    } else {
	$errors .= '<li>' . $this->l('Problem updating settings, invalid information. If this problem persists get in touch, sales@iitc.info') . '</li>';
    }

    // Display the instructions
    $this->_html .= '<fieldset><legend>' . $this->l('Explanation') . '</legend>' . 
      '<p><b>' . $this->l('Gateway ID') . '</b> - ' . $this->l('This needs to be set to the Gateway ID given to you by Cardsave.') . '</p>' .
	  '<p><b>' . $this->l('Gateway Password') . '</b> - ' . $this->l('This needs to be set to the Gateway Password given to you by Cardsave.') . '</p>' .
      '<p><b>' . $this->l('Pre-Shared Key') . '</b> - ' . $this->l('The SHA1 Pre-Shared Key as found in the Cardsave MMS.') . '</p>' .
	  '<p><b>' . $this->l('Debug Mode') . '</b> - ' . $this->l('Show Debugging information (returned Hash etc.) on the return page.') . '</p>' .
      '</fieldset><br>';

    // Display errors / confirmation
    if (isset($_POST['cs_cardsave_SUBMIT']))
      if ($errors)
	$this->_html .= '<div class="alert error"><ul>' . $errors . '</ul></div>';
      else
	$this->_html .= '<div class="conf confirm">' . $this->l('Changes have all been saved') . '</div>';
    
    // Display the form
    $this->_html .= '<form action="' . $_SERVER['REQUEST_URI'] . '" method="post">' .
      '<fieldset class="width2"><legend>' . $this->l('Configuration') . '</legend>' . 
      '<label>' . $this->l('Gateway ID:') . '</label><div class="margin-form"><input name="CS_CARDSAVE_GATEWAYID" type="text" value="' . $this->getSetting('CS_CARDSAVE_GATEWAYID') . '" /></div>' .
	  '<label>' . $this->l('Gateway Password:') . '</label><div class="margin-form"><input name="CS_CARDSAVE_GATEWAYPASS" type="text" value="' . $this->getSetting('CS_CARDSAVE_GATEWAYPASS') . '" /></div>' .
      '<label>' . $this->l('Pre-Shared Key:') . '</label><div class="margin-form"><input type="text" name="CS_CARDSAVE_PSK" value="' . $this->getSetting('CS_CARDSAVE_PSK') . '"/></div>' .
      $this->trueFalseOption('CS_CARDSAVE_DEBUG', 'Debug Mode', 'On', 'Off') .
	  '<input type="submit" name="cs_cardsave_SUBMIT" id="cs_cardsave_SUBMIT" value="' . $this->l('Save your changes') . '" />' .
      '</fieldset></form>';

    return $this->_html;
  }

  //private function getModuleCurrency($cart)
//	{
	//	$id_currency = (int)self::MysqlGetValue('SELECT id_currency FROM `'._DB_PREFIX_.'module_currency` WHERE id_module = '.(int)$this->id);
	//	if (!$id_currency OR $id_currency == -2)
	//		$id_currency = Configuration::get('PS_CURRENCY_DEFAULT');
	//	elseif ($id_currency == -1)
	//		$id_currency = $cart->id_currency;
	//	return $id_currency;
	//}
	
  public function hookPayment($params) {

	if (!$this->active)
      return ;

    $address = new Address(intval($params['cart']->id_address_invoice));
    $customer = new Customer(intval($params['cart']->id_customer));
    $currency = $this->getCurrency();

	$csquery = 'SELECT id_currency FROM ps_module_currency WHERE id_module = 53';
	$db = Db::getInstance();
	$queryresult = $db->getRow($csquery);
	$id1_currency = array_shift($queryresult);
	
	// get currency of current cart.
	$csquery1 = 'SELECT iso_code FROM ps_currency WHERE id_currency = ' . $params['cart']->id_currency;
	$queryresult1 = $db->getRow($csquery1);
	$cart_currency = array_shift($queryresult1);
		
	if (!$id1_currency OR $id1_currency == -2)
		{
			$id2_currency = Configuration::get('PS_CURRENCY_DEFAULT');
		}	
	elseif ($id1_currency == -1)
		{
			$id2_currency = $params['cart']->id_currency;
		}
	
// get currency of current cart.
	$csquery2 = 'SELECT conversion_rate FROM ps_currency WHERE id_currency = ' . $params['cart']->id_currency;
	$queryresult2 = $db->getRow($csquery2);
	$cart_conversion_rate = array_shift($queryresult2);
	
    // Grab the order total and format it properly
	if ($params['cart']->id_currency != $id2_currency)
		{
		//$amount = number_format(Tools::convertPrice($params['cart']->getOrderTotal(true, 3), $queryresult2), 2, '.', '');
		$c_rate = $cart_conversion_rate;
		$price = $params['cart']->getOrderTotal(true, 3) / $c_rate;
		$amount = number_format($price, 2, '.', '');
		$currencycs = $currency->iso_code;
		}
	else
		{
		$amount = number_format($params['cart']->getOrderTotal(true, 3), 2, '.', '');
		$currencycs = $cart_currency;
		}
		
    $amount = sprintf('%0.2f', $amount);
    $amount = preg_replace('/[^\d]+/', '', $amount);

    $parameters = array();

    $module_url = 'http://' . $_SERVER['HTTP_HOST'] . __PS_BASE_URI__ . 'modules/cs_cardsave/';
	
	$cardsave_psk = $this->getSetting('CS_CARDSAVE_PSK');
	$cardsave_gatewaypass = $this->getSetting('CS_CARDSAVE_GATEWAYPASS');
	
	$datestamp = gatewaydatetime();
	$gatewayorderID = generateorderdate() . "~" . $params['cart']->id; 
	
	$HashDigest="PreSharedKey=" . $cardsave_psk;
	$HashDigest.= '&MerchantID=' . $this->getSetting('CS_CARDSAVE_GATEWAYID');
	$HashDigest.= '&Password=' . $cardsave_gatewaypass;
	$HashDigest.= '&Amount=' . $amount;
	$HashDigest.= '&CurrencyCode=' . getCurrencyISO($currencycs);
	$HashDigest.= '&OrderID=' . $gatewayorderID;
	$HashDigest.= '&TransactionType=' . 'SALE';
	$HashDigest.= '&TransactionDateTime=' . $datestamp;
	$HashDigest.= '&CallbackURL=' . $module_url . 'success.php';
	$HashDigest.= '&OrderDescription=' . $gatewayorderID;
	$HashDigest.= '&CustomerName=' . $customer->firstname . ' ' . $customer->lastname;
	$HashDigest.= '&Address1=' . $address->address1;
	$HashDigest.= '&Address2=' . $address->address2;
	$HashDigest.= '&Address3=' . '';
	$HashDigest.= '&Address4=' . '';
	$HashDigest.= '&City=' . $address->city;
	$HashDigest.= '&State=' . '';
	$HashDigest.= '&PostCode=' . $address->postcode;
	$HashDigest.= '&CountryCode=' . getCountryISO($address->country);
	$HashDigest.= '&CV2Mandatory=' . 'True';
	$HashDigest.= '&Address1Mandatory=' . 'True';
	$HashDigest.= '&CityMandatory=' . 'True';
	$HashDigest.= '&PostCodeMandatory=' . 'True';
	$HashDigest.= '&StateMandatory=' . 'False';
	$HashDigest.= '&CountryMandatory=' . 'True';
	$HashDigest.= '&ResultDeliveryMethod=' . 'SERVER';
	$HashDigest.= '&ServerResultURL=' . $module_url . 'callback.php';
	$HashDigest.= '&PaymentFormDisplaysResult=' . 'false';
	$HashDigest.= '&ServerResultURLCookieVariables=' . '';
	$HashDigest.= '&ServerResultURLFormVariables=' . '';
	$HashDigest.= '&ServerResultURLQueryStringVariables=' . '';
	$HashDigest = sha1($HashDigest);
	  
	$parameters['HashDigest'] = $HashDigest;
	$parameters['MerchantID'] = $this->getSetting('CS_CARDSAVE_GATEWAYID');
	$parameters['Amount'] = $amount;
	$parameters['CurrencyCode'] = getCurrencyISO($currencycs);
	$parameters['OrderID'] = $gatewayorderID;
	$parameters['TransactionType'] = 'SALE';
	$parameters['TransactionDateTime'] = $datestamp;
	$parameters['CallbackURL'] = $module_url . 'success.php';
	$parameters['OrderDescription'] = $gatewayorderID;
	$parameters['CustomerName'] = $customer->firstname . ' ' . $customer->lastname;
	$parameters['Address1'] = $address->address1;
	$parameters['Address2'] = $address->address2;
	$parameters['Address3'] = '';
	$parameters['Address4'] = '';
	$parameters['City'] = $address->city; 
	$parameters['State'] = '';
	$parameters['PostCode'] = $address->postcode;
	$parameters['CountryCode'] = getCountryISO($address->country);
	$parameters['CV2Mandatory'] = 'True';
	$parameters['Address1Mandatory'] = 'True';
	$parameters['CityMandatory'] = 'True';
	$parameters['PostCodeMandatory'] = 'True';
	$parameters['StateMandatory'] = 'False';
	$parameters['CountryMandatory'] = 'True';
	$parameters['ResultDeliveryMethod'] = 'SERVER';
	$parameters['ServerResultURL'] = $module_url . 'callback.php';
	$parameters['PaymentFormDisplaysResult'] = 'false';
	$parameters['ServerResultURLCookieVariables'] = '';
	$parameters['ServerResultURLFormVariables'] = '';
	$parameters['ServerResultURLQueryStringVariables'] = '';
    
	$form_target = "https://mms.cardsaveonlinepayments.com/Pages/PublicPages/PaymentForm.aspx";

    global $smarty;
    $smarty->assign(array('parameters' => $parameters,
			  'form_target' => $form_target));
    
    return $this->display(__FILE__, 'cardsave.tpl');
  }
}

function gatewaydatetime()
{
  $str=date('Y-m-d H:i:s O');
  return $str;
}

function generateorderdate()
{
  $str=date('Ymd-His');
  return $str;
}
	
include("CurrencyISOCodes.php");
include("CountryISOCodes.php"); 
?>