<?php

class JVShopping extends Module
{
	public function __construct()
	{
		$this->name 		= 'jvshopping';
		$this->tab 			= 'Products';
		$this->version 		= '0.1';
		$this->author 		= 'JVWEB';
		$this->module_key 	= '055620edf36f9be66d1121de4b158a58';

		$this->displayName		= $this->l('JVShopping');
		$this->description 		= $this->l('With this module, generate a catalog of products suited to our feed management application JVShopping.');
		$this->confirmUninstall = $this->l('Are you sure you want to uninstall the JVShopping module ?');

		parent::__construct();

		if (!Configuration::get('JVSHOPPING_EXPORT_TYPE'))
		{
			$this->warning = $this->l('You have not yet set the export type');
		}
	}

	public function install()
	{
		return parent::install();
	}

	public function uninstall()
	{
		return 
		(
			Configuration::deleteByName('JVSHOPPING_EXPORT_TYPE')
				AND
			Configuration::deleteByName('JVSHOPPING_REWRITTEN_URLS')	
				AND
			parent::uninstall()
		);
	}

	public function getContent()
	{
		$output = '
		<h2>JVShopping</h2>
		<p>'.$this->l('With this module, generate a catalog of products suited to our feed management application JVShopping.').'</p>
		<br clear="all" />';

		if (Tools::isSubmit('submitJVShopping'))
		{
			$jvt 	= Tools::getValue('jvshopping_export_type');
			$jvru 	= Tools::getValue('jvshopping_rewritten_urls');
			
			Configuration::updateValue('JVSHOPPING_EXPORT_TYPE',	 $jvt);
			Configuration::updateValue('JVSHOPPING_REWRITTEN_URLS', $jvru);
			
			$output .= '
			<div class="conf confirm">
				<img src="../img/admin/ok.gif" alt="" title="" />
				'.$this->l('Settings updated').'
			</div>';
		}

		//Catalog's URL with the default language
		$catalogExportUrl	= 'http://'.$_SERVER['HTTP_HOST'].constant('__PS_BASE_URI__').'modules/jvshopping/export.php';

		$output2 = '
			<br clear="all" />
			<fieldset>
				<legend><img src="../img/admin/information.png" alt="" class="middle" />'.$this->l('URL of your product catalog').' - '.$this->l('Default language of your website').'</legend>
				<a href="'.$catalogExportUrl.'" target="_blank">'.$catalogExportUrl.'</a>
			</fieldset>
		';

		//URL for the different languages
		$query = 'SELECT id_lang, name, iso_code FROM '.constant('_DB_PREFIX_').'lang WHERE active=1 ORDER BY name ASC';
		$data_languages = Db::getInstance()->ExecuteS($query);

		foreach($data_languages as $language)
		{
			$output2 .=	'
				<br clear="all" />
				<fieldset>
					<legend><img src="../img/l/'.$language['id_lang'].'.jpg" alt="" class="midlle" />'.$this->l('URL of your product catalog').' - '.$language["name"].'</legend>
						<a href="'.$catalogExportUrl.'?l='.$language["iso_code"].'" target="_blank">'.$catalogExportUrl.'?l='.$language["iso_code"].'</a>
				</fieldset>
			';
		}

		$output2 .= '
			<br clear="all" />
			<fieldset>
				<legend><img src="../img/admin/information.png" alt="" class="middle" />'.$this->l('Documentation').'</legend>
				<a href="http://www.jvweb.fr/jvshopping/prestashop/1.4/readme_en.pdf" target="_blank"><img src="../img/l/1.jpg" alt="" class="midlle" />readme_en.pdf</a>
				&nbsp;&nbsp;
				<a href="http://www.jvweb.fr/jvshopping/prestashop/1.4/readme_fr.pdf" target="_blank"><img src="../img/l/2.jpg" alt="" class="midlle" />readme_fr.pdf</a>
			</fieldset>
		';
		
		
		
		return $output.$this->displayForm().$output2;
	}

	public function displayForm()
	{
		//Export Type
		$export_type 	= Tools::getValue('jvshopping_export_type', Configuration::get('JVSHOPPING_EXPORT_TYPE'));

		$urls_rewritten 	= Tools::getValue('jvshopping_rewritten_urls', Configuration::get('JVSHOPPING_REWRITTEN_URLS'));

		$checked = ($urls_rewritten == "on")?"checked":"";
		
		$selectedClassicType	= $export_type	== 'classic'	? 'selected="selected"' : '';
		$selectedFullType		= $export_type	== 'full'		? 'selected="selected"' : '';
	
		//Output
		$output = '
			<form action="'.$_SERVER['REQUEST_URI'].'" method="post">
				<fieldset class="width2">
					<legend><img src="../img/admin/cog.gif" alt="" class="middle" />'.$this->l('Settings').'</legend>
					<label>'.$this->l('Export type').'</label>
					<div class="margin-form">
						<select name="jvshopping_export_type">
							<option value="classic" '.$selectedClassicType.'>'.$this->l('Classic').'</option>
							<option value="full" '.$selectedFullType.'>'.$this->l('Full').'</option>
						</select>
						<ul>
							<li>'.$this->l('With the "Classic" type you can export a line by product.').'<br /><br /></li>
							<li>'.$this->l('With the "Full" type, you can export a line by product declination.').'</li>
						<ul>
					</div>
					<label>'.$this->l('Url rewriting').'</label>
					<div class="margin-form">
						<input type="checkbox" name="jvshopping_rewritten_urls" '.$checked.'>
						<ul>
							<li>'.$this->l('When checked, rewritten urls will be exported as defined in Prestashop (slower). This works if url rewriting is on in Prestashop and web server (htaccess)').'</li>
						<ul>
					</div>
					<center><input type="submit" name="submitJVShopping" value="'.$this->l('Save').'" class="button" /></center>
				</fieldset>
			</form>
		';

		return $output;
	}
}


