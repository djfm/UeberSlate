<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{jvshopping}prestashop>jvshopping_08daec8502f7613c9284cd88cbfdaf7b'] = 'JVShopping';
$_MODULE['<{jvshopping}prestashop>jvshopping_d3a83d18bb1ccfd772600adde3c6d18c'] = 'Grâce à ce module, générez un catalogue produits adapté à notre solution de gestion de flux JVShopping';
$_MODULE['<{jvshopping}prestashop>jvshopping_c3623d3a8ee5401da3e6c722fff51581'] = 'Êtes vous sur de vouloir desitaller le module JVShopping ?';
$_MODULE['<{jvshopping}prestashop>jvshopping_65dd4c94091d36149dc577b787bbedef'] = 'Vous n\'avez pas encore spécifié le type d\'export';
$_MODULE['<{jvshopping}prestashop>jvshopping_c888438d14855d7d96a2724ee9c306bd'] = 'Paramètres mis à jour';
$_MODULE['<{jvshopping}prestashop>jvshopping_405d03563a8561c3a997bf700e501a5f'] = 'URL de votre catalogue produits';
$_MODULE['<{jvshopping}prestashop>jvshopping_b6606c3aa60cea2de54aad376d099353'] = 'Langue par défault de votre site web';
$_MODULE['<{jvshopping}prestashop>jvshopping_f4f70727dc34561dfde1a3c529b6205c'] = 'Paramètres';
$_MODULE['<{jvshopping}prestashop>jvshopping_36f07a9e1ce283822836fdb33f482b1f'] = 'Type d\'export';
$_MODULE['<{jvshopping}prestashop>jvshopping_d35b51b639528d580362ca7042de6a0e'] = 'Classique';
$_MODULE['<{jvshopping}prestashop>jvshopping_bbd47109890259c0127154db1af26c75'] = 'Complet';
$_MODULE['<{jvshopping}prestashop>jvshopping_def6749d3f7f89d70b10df0e19443fd8'] = 'Avec le type \"Classique\" votre catalogue comportera une ligne par produit.';
$_MODULE['<{jvshopping}prestashop>jvshopping_65b4593ace905750735391ff07ded3cb'] = 'Avec le type \"Complet\" votre catalogue comportera une ligne par produit ainsi qu\'une ligne par déclinaison de produit.';
$_MODULE['<{jvshopping}prestashop>jvshopping_460117362766df58354727cef3739d17'] = 'Réecriture d\'url';
$_MODULE['<{jvshopping}prestashop>jvshopping_719857000e43ff8842c6e737d9e4954c'] = 'Si cochée, les url des produits exportés seront réécrites telles que définies dans Prestashop (plus lent). Cela ne marche que si la réécriture d\'url est activée au sein de Prestashop et du serveur web (htaccess).';
$_MODULE['<{jvshopping}prestashop>jvshopping_c9cc8cce247e49bae79f15173ce97354'] = 'Sauvegarder';
