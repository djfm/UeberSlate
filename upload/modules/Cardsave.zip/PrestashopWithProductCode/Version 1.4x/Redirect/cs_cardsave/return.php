<?php
/*
This file is part of the Prestashop CardSave Re-Directed Payment Module
See cs_cardsave.php for Licensing and support info.
File Last Modified: 07/12/2010 - By Alistair Richardson - CardSave Online
*/

include(dirname(__FILE__) . '/../../config/config.inc.php');
include(dirname(__FILE__) . '/cs_cardsave.php');

if(intval(Configuration::get('PS_REWRITING_SETTINGS')) === 1)
    $rewrited_url = __PS_BASE_URI__;

include(dirname(__FILE__).'/../../header.php');

$smarty->assign('cartURL', 'http://' . $_SERVER['HTTP_HOST'] . __PS_BASE_URI__ . 'order.php?step=1');
$smarty->assign('contactURL', 'http://' . $_SERVER['HTTP_HOST'] . __PS_BASE_URI__ . 'contact-form.php');

$smarty->display(dirname(__FILE__) . '/return.tpl');

include(dirname(__FILE__).'/../../footer.php');
