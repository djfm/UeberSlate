<?php
session_start();

include(dirname(__FILE__). '/../../config/config.inc.php');
include(dirname(__FILE__). '/../../init.php');
include(dirname(__FILE__). '/cs_cardsave_direct.php');
require_once ("ThePaymentGateway/PaymentSystem.php");

$gateway_id = Configuration::get('CARDSAVE_DIRECT_GATEWAY_ID');
$gateway_password = Configuration::get('CARDSAVE_DIRECT_PASSWORD');
$gateway_domain = Configuration::get('CARDSAVE_DIRECT_PROCESSOR_DOMAIN');
$gateway_port = Configuration::get('CARDSAVE_DIRECT_PROCESSOR_PORT');

$CrossReference = $_POST['MD'];
$PaRES = $_POST['PaRes'];

$rgeplRequestGatewayEntryPointList = new RequestGatewayEntryPointList();

$rgeplRequestGatewayEntryPointList->add("https://gw1.".$gateway_domain.":".$gateway_port, 100, 2);
$rgeplRequestGatewayEntryPointList->add("https://gw2.".$gateway_domain.":".$gateway_port, 200, 2);
$rgeplRequestGatewayEntryPointList->add("https://gw3.".$gateway_domain.":".$gateway_port, 300, 2);

$mdMerchantDetails = new MerchantDetails($gateway_id, $gateway_password);

$tdsidThreeDSecureInputData = new ThreeDSecureInputData($CrossReference, $PaRES);

$tdsaThreeDSecureAuthentication = new ThreeDSecureAuthentication($rgeplRequestGatewayEntryPointList, 1, null, $mdMerchantDetails, $tdsidThreeDSecureInputData, "Some data to be passed out");
$boTransactionProcessed = $tdsaThreeDSecureAuthentication->processTransaction($goGatewayOutput, $tomTransactionOutputMessage);

$order_amount = $_SESSION['order_amount'];
unset($_SESSION['order_amount']);

$cart_id = $_SESSION['cart_id'];
unset($_SESSION['cart_id']);

$order_number = $_SESSION['order_id'];
unset($_SESSION['order_id']);

if ($boTransactionProcessed == false)
{
	// could not communicate with the payment gateway
	$NextFormMode = "RESULTS";
	$Message = "Couldn't communicate with payment gateway";
	$TransactionSuccessful = false;
}
else
{
	switch ($goGatewayOutput->getStatusCode())
	{
		case 0:
			// status code of 0 - means transaction successful
			$NextFormMode = "RESULTS";
			$AuthCode = $tomTransactionOutputMessage->getAuthCode();
			$Message .= "PAYMENT SUCCESSFUL <br> ";
			$Message .= "MMS Order ID: " . $order_number . " <br> ";
			$Message .=	"Auth Code: " . $tomTransactionOutputMessage->getAuthCode() . " <br> ";
			$Message .= "Cross Reference: " . $tomTransactionOutputMessage->getCrossReference() . " <br> ";
			$Message .=	"Address Check: " . $tomTransactionOutputMessage->getAddressNumericCheckResult()->getValue() . " <br> ";
			$Message .=	"Postcode Check: " . $tomTransactionOutputMessage->getPostCodeCheckResult()->getValue() . " <br> ";
			$Message .=	"CV2 Check: " . $tomTransactionOutputMessage->getCV2CheckResult()->getValue() . " <br> ";
			$Message .=	"3D Secure Result: " . $tomTransactionOutputMessage->getThreeDSecureAuthenticationCheckResult()->getValue();
			$TransactionSuccessful = true;
			break;
		case 4:
			// status code of 4 - means transaction referred 
			$NextFormMode = "RESULTS";
			$Payment_Error = $goGatewayOutput->getMessage();
			$Message =	"CARD REFERRED <br> ";
			$Message .= "MMS Order ID: " . $order_number . " <br> ";
			$Message .=	"Message: " . $goGatewayOutput->getMessage() . " <br> ";
			$Message .= "Cross Reference: " . $tomTransactionOutputMessage->getCrossReference() . " <br> ";
			$Message .=	"Address Check: " . $tomTransactionOutputMessage->getAddressNumericCheckResult()->getValue() . " <br> ";
			$Message .=	"Postcode Check: " . $tomTransactionOutputMessage->getPostCodeCheckResult()->getValue() . " <br> ";
			$Message .=	"CV2 Check: " . $tomTransactionOutputMessage->getCV2CheckResult()->getValue() . " <br> ";
			$Message .=	"3D Secure Result: " . $tomTransactionOutputMessage->getThreeDSecureAuthenticationCheckResult()->getValue();
			$TransactionSuccessful = false;
			break;
		case 5:
			// status code of 5 - means transaction declined 
			$NextFormMode = "RESULTS";
			$Payment_Error = $goGatewayOutput->getMessage();
			$Message =	"CARD DECLINED <br> ";
			$Message .= "MMS Order ID: " . $order_number . " <br> ";
			$Message .=	"Message: " . $goGatewayOutput->getMessage() . " <br> ";
			$Message .= "Cross Reference: " . $tomTransactionOutputMessage->getCrossReference() . " <br> ";
			$Message .=	"Address Check: " . $tomTransactionOutputMessage->getAddressNumericCheckResult()->getValue() . " <br> ";
			$Message .=	"Postcode Check: " . $tomTransactionOutputMessage->getPostCodeCheckResult()->getValue() . " <br> ";
			$Message .=	"CV2 Check: " . $tomTransactionOutputMessage->getCV2CheckResult()->getValue() . " <br> ";
			$Message .=	"3D Secure Result: " . $tomTransactionOutputMessage->getThreeDSecureAuthenticationCheckResult()->getValue();
			
			$TransactionSuccessful = false;
			break;
		case 20:
			// status code of 20 - means duplicate transaction 
			$NextFormMode = "RESULTS";
			$Message = $goGatewayOutput->getMessage();
			
			if ($goGatewayOutput->getPreviousTransactionResult()->getStatusCode()->getValue() == 0)
			{
				$TransactionSuccessful = true;
			}
			else
			{
				$TransactionSuccessful = false;
			}
			$PreviousTransactionMessage = $goGatewayOutput->getPreviousTransactionResult()->getMessage();
			$DuplicateTransaction = true;
			break;
		case 30:
			// status code of 30 - means an error occurred 
			$NextFormMode = "RESULTS";
			$Message = $goGatewayOutput->getMessage();
			
			if ($goGatewayOutput->getErrorMessages()->getCount() > 0)
			{
				$Message = $Message."<br /><ul>";

				for ($LoopIndex = 0; $LoopIndex < $goGatewayOutput->getErrorMessages()->getCount(); $LoopIndex++)
				{
					$Message = $Message."<li>".$goGatewayOutput->getErrorMessages()->getAt($LoopIndex)."</li>";
				}
				$Message = $Message."</ul>";
				$TransactionSuccessful = false;
			}
			break;
		default:
			// unhandled status code  
			$NextFormMode = "RESULTS";
			$Message=$goGatewayOutput->getMessage();
			$TransactionSuccessful = false;
			break;
	}
}

$cart = new Cart($cart_id);
if (!Validate::isLoadedObject($cart))
{
	Logger::addLog('Cart loading failed for cart '.$cart_id, 4);
	echo 'Cart loading failed for cart' . $cart_id;
	exit;
}

$customer = new Customer((int)$cart->id_customer);

$cs_cardsave_direct = new cs_cardsave_direct();

if ($TransactionSuccessful) {
	$cs_cardsave_direct->validateOrder((int)$cart->id, Configuration::get('PS_OS_PAYMENT'), $order_amount/100, "CardSave Direct", $Message, NULL, NULL, false, $customer->secure_key);	
	Tools::redirect('order-confirmation.php?id_module='.(int)$cs_cardsave_direct->id.'&id_cart='.(int)$cart->id.'&key='.$customer->secure_key.'&ac='.$AuthCode.'&orderid='.$cs_cardsave_direct->currentOrder);
} else {
	$cs_cardsave_direct->validateOrder((int)$cart->id, Configuration::get('PS_OS_ERROR'), $order_amount/100, "CardSave Direct", $Message, NULL, NULL, false, $customer->secure_key);
	Tools::redirect('order-confirmation.php?id_module='.(int)$cs_cardsave_direct->id.'&id_cart='.(int)$cart->id.'&key='.$customer->secure_key.'&err='.$Payment_Error.'&orderid='.$cs_cardsave_direct->currentOrder);
}
