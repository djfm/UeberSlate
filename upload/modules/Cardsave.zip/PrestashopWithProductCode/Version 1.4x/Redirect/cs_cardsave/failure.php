<?php
/*
This file is part of the Prestashop CardSave Re-Directed Payment Module
See cs_cardsave.php for Licensing and support info.
File Last Modified: 07/12/2010 - By Alistair Richardson - CardSave Online
*/

include(dirname(__FILE__) . '/../../config/config.inc.php');
include(dirname(__FILE__) . '/cs_cardsave.php');

if(intval(Configuration::get('PS_REWRITING_SETTINGS')) === 1)
    $rewrited_url = __PS_BASE_URI__;

$cardsave = new cs_cardsave();

include(dirname(__FILE__).'/../../header.php');
$advice = "<a href='javascript: history.go(-1)'>" . $cardsave->l("click here") . "</a>";

$smarty->assign('contactURL', 'http://' . $_SERVER['HTTP_HOST'] . __PS_BASE_URI__ . 'contact-form.php');
$smarty->assign('advice', $advice);

$smarty->display(dirname(__FILE__) . '/failure.tpl');

include(dirname(__FILE__).'/../../footer.php');

