<?php

ini_set('memory_limit', '512M');
set_time_limit(0);

include("catalogExport.php");

header('Content-Type: text/plain; charset=utf-8');

$exporter = new CatalogExport();
$exporter->export();