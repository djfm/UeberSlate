<?php
/*
* 2007-2011 PrestaShop 
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author PrestaShop SA <contact@prestashop.com>
*  @copyright  2007-2011 PrestaShop SA
*  @version  Release: $Revision: 7732 $
*  @license    http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

if (!defined('_CAN_LOAD_FILES_'))
	exit;
	
class cs_cardsave_direct extends PaymentModule
{
	public function __construct()
	{
		$this->name = 'cs_cardsave_direct';
		$this->tab = 'payments_gateways';
		$this->version = '1.0';
		$this->author = 'CardSave Online';
		$this->module_key = "1e631b52ed3d1572df477b9ce182ccf8";
		$this->need_instance = 0;
		
		$this->currencies = true;
	    $this->currencies_mode = 'radio'; 

        parent::__construct();

        $this->displayName = 'CardSave Direct';
        $this->description = $this->l('Process transactions through the CardSave gateway.');
	}

	public function install()
	{
		return (parent::install() AND $this->registerHook('orderConfirmation') AND $this->registerHook('payment') AND Configuration::updateValue('CARDSAVE_DIRECT_DEMO', 1));
	}

	public function uninstall()
	{
		Configuration::deleteByName('CARDSAVE_DIRECT_GATEWAY_ID');
		Configuration::deleteByName('CARDSAVE_DIRECT_PASSWORD');
		Configuration::deleteByName('CARDSAVE_DIRECT_PROCESSOR_DOMAIN');
		Configuration::deleteByName('CARDSAVE_DIRECT_PROCESSOR_PORT');

		return parent::uninstall();
	}

	public function hookOrderConfirmation($params)
	{
		global $smarty; 

		if ($params['objOrder']->module != $this->name) 
			return;

		if ($params['objOrder']->getCurrentState() != Configuration::get('PS_OS_ERROR')) 
			$smarty->assign(array('status' => 'ok', 'id_order' => intval($params['objOrder']->id)));
		else
			$smarty->assign('status', 'failed');

		return $this->display(__FILE__, 'hookorderconfirmation.tpl'); 
	}

	public function getContent()
	{
		if (Tools::isSubmit('submitModule'))
		{
			Configuration::updateValue('CARDSAVE_DIRECT_GATEWAY_ID', Tools::getvalue('cs_cardsave_direct_gateway_id'));
			Configuration::updateValue('CARDSAVE_DIRECT_PASSWORD', Tools::getvalue('cs_cardsave_direct_password'));			
			Configuration::updateValue('CARDSAVE_DIRECT_PROCESSOR_DOMAIN', Tools::getvalue('cs_cardsave_direct_processor_domain'));
			Configuration::updateValue('CARDSAVE_DIRECT_PROCESSOR_PORT', Tools::getvalue('cs_cardsave_direct_processor_port'));

			echo $this->displayConfirmation($this->l('Configuration updated'));
		}

		return '
		<h2>'.$this->displayName.'</h2>
		<fieldset><legend><img src="../modules/'.$this->name.'/logo.gif" alt="" /> '.$this->l('Help').'</legend>
			<a href="http://www.CardSave.net/"><img src="../modules/'.$this->name.'/Cardsave_logo.png" alt="" /></a><br /><br />
			<b>'. $this->displayName. '</b><br />
			<b>Module Version:</b> '. $this->version .'<br />
			<u style="color:#015692;"><a href="https://mms.cardsaveonlinepayments.com" target="_blank">CardSave Merchant Management System</a></u><br /><br />
			<h3>'.$this->l('Configuration Help').'</h3>
			- '.$this->l('Fill the Gateway ID field with the one provided by CardSave').'<br />
			- '.$this->l('Fill the Gateway Password field with the one provided by CardSave').'<br />
			- '.$this->l('Enter <b>cardsaveonlinepayments.com</b> into the Gateway Processor Domain field').'<br />
			- '.$this->l('Enter <b>4430</b> into the Gateway Processor Port field').'<br /><br />
			<span style="color: red;" >'.$this->l('Warning: Your website must possess a SSL certificate to use the CardSave payment system. You are responsible for the safety of your customers\' bank information. PrestaShop cannot be blamed for any security issue on your website.').'</span><br />
			<br />
		</fieldset><br />
		<form action="'.Tools::htmlentitiesutf8($_SERVER['REQUEST_URI']).'" method="post">
			<fieldset class="width2">
				<legend><img src="../img/admin/contact.gif" alt="" />'.$this->l('Settings').'</legend>
				<label for="cs_cardsave_direct_gateway_id">'.$this->l('Gateway ID').'</label>
				<div class="margin-form"><input type="text" size="20" id="cs_cardsave_direct_gateway_id" name="cs_cardsave_direct_gateway_id" value="'.Configuration::get('CARDSAVE_DIRECT_GATEWAY_ID').'" /></div>
				<label for="cs_cardsave_direct_password">'.$this->l('Gateway Password').'</label>
				<div class="margin-form"><input type="text" size="20" id="cs_cardsave_direct_password" name="cs_cardsave_direct_password" value="'.Configuration::get('CARDSAVE_DIRECT_PASSWORD').'" /></div>
				<label for="cs_cardsave_direct_processor_domain">'.$this->l('Gateway Processor Domain').'</label>
				<div class="margin-form"><input type="text" size="35" id="cs_cardsave_direct_processor_domain" name="cs_cardsave_direct_processor_domain" value="'.Configuration::get('CARDSAVE_DIRECT_PROCESSOR_DOMAIN').'" /></div>
				<label for="cs_cardsave_direct_processor_port">'.$this->l('Gateway Processor Port').'</label>
				<div class="margin-form"><input type="text" size="10" id="cs_cardsave_direct_processor_port" name="cs_cardsave_direct_processor_port" value="'.Configuration::get('CARDSAVE_DIRECT_PROCESSOR_PORT').'" /></div>
				<br /><center><input type="submit" name="submitModule" value="'.$this->l('Update settings').'" class="button" /></center>
			</fieldset>
		</form>';
	}

	public function hookPayment($params)
	{
		global $cookie, $smarty;

		$invoiceAddress = new Address((int)$params['cart']->id_address_invoice);
		$customer = new Customer((int)$cookie->id_customer);
		
		$cs_cardsave_directParams = array();
		//$cs_cardsave_directParams['gateway_id'] = Configuration::get('CARDSAVE_DIRECT_GATEWAY_ID');
		//$cs_cardsave_directParams['gateway_password'] = Configuration::get('CARDSAVE_DIRECT_PASSWORD');
		$cs_cardsave_directParams['gateway_transtype'] = 'SALE';
		$cs_cardsave_directParams['cart_id'] = (int)$params['cart']->id;		
		$cs_cardsave_directParams['order_amount'] = $params['cart']->getOrderTotal(true, 3)*100;
		$cs_cardsave_directParams['order_address1'] = $invoiceAddress->address1;
		$cs_cardsave_directParams['order_address2'] = $invoiceAddress->address2;
		$cs_cardsave_directParams['order_address3'] = "";
		$cs_cardsave_directParams['order_address4'] = "";
		$cs_cardsave_directParams['order_city'] = $invoiceAddress->city;
		$cs_cardsave_directParams['order_postcode'] = $invoiceAddress->postcode;
		$cs_cardsave_directParams['order_name'] = $customer->firstname . ' ' . $customer->lastname;
		$cs_cardsave_directParams['order_phone'] = $invoiceAddress->phone;
		$cs_cardsave_directParams['order_email'] = $customer->email;
		$cs_cardsave_directParams['order_ip'] = $_SERVER['REMOTE_ADDR'];
		
		$isFailed = Tools::getValue('aimerror');

		$smarty->assign('p', $cs_cardsave_directParams);
		$smarty->assign('isFailed', $isFailed);

		//return __FILE__;
	
		return $this->display(__FILE__, 'cs_cardsave_direct.tpl');
		
    }
}
?>
