<?php
/*
This file is part of the Prestashop CardSave Re-Directed Payment Module
See cs_cardsave.php for Licensing and support info.
File Last Modified: 02/08/2011 - By Alistair Richardson - CardSave Online
*/

include(dirname(__FILE__) . '/../../config/config.inc.php');
include(dirname(__FILE__) . '/cs_cardsave.php');

if(intval(Configuration::get('PS_REWRITING_SETTINGS')) === 1)
    $rewrited_url = __PS_BASE_URI__;

include(dirname(__FILE__).'/../../header.php');

function createhash()
{ 
  $str="PreSharedKey=" . Configuration::get('CS_CARDSAVE_PSK');
  $str=$str . '&MerchantID=' . Configuration::get('CS_CARDSAVE_GATEWAYID');
  $str=$str . '&Password=' . Configuration::get('CS_CARDSAVE_GATEWAYPASS');
  $str=$str . '&CrossReference=' . $_GET["CrossReference"];
  $str=$str . '&OrderID=' . $_GET["OrderID"];
  return sha1($str);
}  

function createhashvalues()
{ 
  $str="PreSharedKey=" . Configuration::get('CS_CARDSAVE_PSK');
  $str=$str . '&MerchantID=' . Configuration::get('CS_CARDSAVE_GATEWAYID');
  $str=$str . '&Password=' . Configuration::get('CS_CARDSAVE_GATEWAYPASS');
  $str=$str . '&CrossReference=' . $_GET["CrossReference"];
  $str=$str . '&OrderID=' . $_GET["OrderID"];
  return $str;
} 

$ReturnMessage = "";
$DebugMessage = "<h3>Debug</h3>";
$CartID = substr($_GET["OrderID"], strpos($_GET["OrderID"],"~") + 1);

if ($_GET["HashDigest"] != "" && $CartID > 0) {
   $passedhash = $_GET["HashDigest"];
   $genhash = createhash();
   if ($genhash == $passedhash)  {
		$DebugMessage .= "<p><b>Hash Check:</b> Passed</p>";
   		$SQL = 'SELECT CONCAT('. _DB_PREFIX_ .'orders.id_order, "|", '. _DB_PREFIX_ .'order_history.id_order_state, "|",'. _DB_PREFIX_ .'order_state_lang.name, "|",'. _DB_PREFIX_ .'message.message) as returnedstring FROM '.
			_DB_PREFIX_ .'orders, '.
			_DB_PREFIX_ .'order_history, '.
			_DB_PREFIX_ .'order_state_lang, '.
			_DB_PREFIX_ .'message '.
		'WHERE '.
			_DB_PREFIX_ .'order_history.id_order = '. _DB_PREFIX_ .'orders.id_order AND '.
			_DB_PREFIX_ .'order_state_lang.id_lang = '. _DB_PREFIX_ .'orders.id_lang AND '.
			_DB_PREFIX_ .'order_state_lang.id_order_state = '. _DB_PREFIX_ .'order_history.id_order_state AND '.
			_DB_PREFIX_ .'message.id_order = '. _DB_PREFIX_ .'orders.id_order AND '.
			_DB_PREFIX_ .'orders.id_cart = ' . $CartID;
		
		$DBResult = Db::getInstance()->getValue($SQL);
		$DebugMessage .= "<p><b>MySQL Query:</b> " . $SQL . "</p>";
		$DebugMessage .= "<p><b>DB Result:</b> " . $DBResult . "</p>";
		
		if (strlen($DBResult) > 0) {
			$OrderDetails = explode('|',$DBResult);
			$DebugMessage .= "<p><b>Order ID:</b> " . $OrderDetails[0] . "</p>";
			$DebugMessage .= "<p><b>Order Status ID:</b> " . $OrderDetails[1] . "</p>";
			$DebugMessage .= "<p><b>Order Status:</b> " . $OrderDetails[2] . "</p>";
			$DebugMessage .= "<p><b>Order Message:</b> " . $OrderDetails[3] . "</p>";
			
			if ($OrderDetails[1] == 2) {
				$ReturnMessage .= "<h3>Payment Successful</h3><p>Your payment was successful, you should receive a confirmation by email from us shortly.</p>";
				$ReturnMessage .= "<p><b>Order Status:</b> " . $OrderDetails[2] . "</p>";
				$ReturnMessage .= "<p><b>Order Message:</b> " . $OrderDetails[3] . "</p>";
				$ReturnMessage .= "<p>Thank you for your order.</p>";
			} else if ($OrderDetails[1] == 8) { 
				$ReturnMessage .= "<h3>Payment Failed</h3><p>There has been a problem with your payment. Your order has not been successful.<br>The message below was returned from the payment gateway.</p>";
				$ReturnMessage .= "<p><b>Order Status:</b> " . $OrderDetails[2] . "</p>";
				$ReturnMessage .= "<p><b>Order Message:</b> " . $OrderDetails[3] . "</p>";
				$ReturnMessage .= "<p>Please try the payment again or try another card.</p>";
			} else if ($OrderDetails[1] == 9) { 
				$ReturnMessage .= "<h3>Out of Stock</h3><p>Payment has been taken but your order is on hold. Please contact us for more information about your order.</p>";
				$ReturnMessage .= "<p><b>Order Status:</b> " . $OrderDetails[2] . "</p>";
				$ReturnMessage .= "<p><b>Order Message:</b> " . $OrderDetails[3] . "</p>";
			} else {
				$ReturnMessage .= "<h3>Payment Failed</h3><p>There has been a problem with your payment. Your order is on hold.</p>";
				$ReturnMessage .= "<p><b>Order Status:</b> " . $OrderDetails[2] . "</p>";
				$ReturnMessage .= "<p><b>Order Message:</b> " . $OrderDetails[3] . "</p>";
				$ReturnMessage .= "<p>Please contact us to proceed with your order or try your payment again.</p>";
			}
		} else {
			$DebugMessage .= "<p><b></b> " . $DBResult . "</p>";
		}		
		
	} else { 
		$ReturnMessage .= "<h3>Order Not Processed</h3><p>Your order has not been processed further. Please contact us quoting the message below.</p>";
        $ReturnMessage .= "<p><b>Hash Check:</b> Failed</p>";
		$DebugMessage .= "<p><b>Hash Check:</b> Failed</p>";
   }
   $DebugMessage .= "<p><b>Passed Hash:</b> " . $passedhash . "</p>";
   $DebugMessage .= "<p><b>Generated Hash:</b> " . $genhash . "</p>";
   $DebugMessage .= "<p><b>Hash Values:</b> " . createhashvalues() . "</p>";
}

if (Configuration::get('CS_CARDSAVE_DEBUG')=="True") {
	$ReturnMessage .= $DebugMessage;
}

$smarty->assign('ReturnMessage', $ReturnMessage);

$smarty->display(dirname(__FILE__) . '/success.tpl');

include(dirname(__FILE__).'/../../footer.php');
?>