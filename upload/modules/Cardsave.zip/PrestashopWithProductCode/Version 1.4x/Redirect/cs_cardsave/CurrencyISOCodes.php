<?php
/*
This file is part of the Prestashop CardSave Re-Directed Payment Module
See cs_cardsave.php for Licensing and support info.
File Last Modified: 07/12/2010 - By Alistair Richardson - CardSave Online
*/
function getCurrencyISO($CurrencyShortName)
{	
	$currencyISO[] = 32;
	$currencyCountryShort[] = "ARS";
	$currencyISO[] = 36;	
	$currencyCountryShort[] = "AUD";
	$currencyISO[] = 986;	
	$currencyCountryShort[] = "BRL";
	$currencyISO[] = 124;	
	$currencyCountryShort[] = "CAD";
	$currencyISO[] = 756;	
	$currencyCountryShort[] = "CHF";
	$currencyISO[] = 152;	
	$currencyCountryShort[] = "CLP";
	$currencyISO[] = 156;	
	$currencyCountryShort[] = "CNY";
	$currencyISO[] = 170;	
	$currencyCountryShort[] = "COP";
	$currencyISO[] = 203;	
	$currencyCountryShort[] = "CZK";
	$currencyISO[] = 208;	
	$currencyCountryShort[] = "DKK";
	$currencyISO[] = 978;	
	$currencyCountryShort[] = "EUR";
	$currencyISO[] = 826;	
	$currencyCountryShort[] = "GBP";
	$currencyISO[] = 344;	
	$currencyCountryShort[] = "HKD";
	$currencyISO[] = 348;	
	$currencyCountryShort[] = "HUF";
	$currencyISO[] = 360;	
	$currencyCountryShort[] = "IDR";
	$currencyISO[] = 352;	
	$currencyCountryShort[] = "ISK";
	$currencyISO[] = 392;	
	$currencyCountryShort[] = "JPY";
	$currencyISO[] = 404;	
	$currencyCountryShort[] = "KES";
	$currencyISO[] = 410;	
	$currencyCountryShort[] = "KRW";
	$currencyISO[] = 484;	
	$currencyCountryShort[] = "MXN";
	$currencyISO[] = 458;	
	$currencyCountryShort[] = "MYR";
	$currencyISO[] = 578;	
	$currencyCountryShort[] = "NOK";
	$currencyISO[] = 554;	
	$currencyCountryShort[] = "NZD";
	$currencyISO[] = 608;	
	$currencyCountryShort[] = "PHP";
	$currencyISO[] = 985;	
	$currencyCountryShort[] = "PLN";
	$currencyISO[] = 752;	
	$currencyCountryShort[] = "SEK";
	$currencyISO[] = 702;	
	$currencyCountryShort[] = "SGD";
	$currencyISO[] = 764;	
	$currencyCountryShort[] = "THB";
	$currencyISO[] = 901;	
	$currencyCountryShort[] = "TWD";
	$currencyISO[] = 840;	
	$currencyCountryShort[] = "USD";
	$currencyISO[] = 704;	
	$currencyCountryShort[] = "VND";
	$currencyISO[] = 710;	
	$currencyCountryShort[] = "ZAR";

	$position = array_search($CurrencyShortName,$currencyCountryShort);
	if ($position !== false) {
		return $currencyISO[$position];
	} else {
		return "error - cannot find currency";
	}		
}
?>