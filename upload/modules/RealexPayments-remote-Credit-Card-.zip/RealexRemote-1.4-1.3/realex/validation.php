<?php
include(dirname(__FILE__).'/../../config/config.inc.php');
include(dirname(__FILE__).'/../../header.php');
include(dirname(__FILE__).'/realex.php');

$realex = new realex();

//Check the data sended by the payment form
$retourError = $realex -> getAuth($_POST);

//If no error
if (empty($retourError)){
	//CONTACT REALEX
	//Initialise arrays
	$parentElements = array();
	$TSSChecks = array();
	$currentElement = 0;
	$currentTSSCheck = "";
	
	$amount 		= $realex -> amount;
	$currency	= $realex -> currency;
	$cardnumber = $realex -> cardnumber;
	$cardname 	= $realex -> cardname;
	$cardtype 	= $realex -> cardtype;
	if ($cardtype=="UK Maestro")
		$cardtype="SWITCH";
	$expdate 	= $realex -> expdate;
	$secure 		= $realex -> secure;
	$currency 	= $realex -> currency;
	$merchantid = $realex -> realexId;
	$secret 		= $realex -> sharedSecret;
	$account 	= $realex -> account;
	$issueno		= $realex -> issueno;
	
	if ($cardtype != "LASER")
		$presind=1;
	else
		$presind=3;
	
	//Creates timestamp that is needed to make up orderid
	$timestamp = strftime("%Y%m%d%H%M%S");
	mt_srand((double)microtime()*1000000);
	
	$orderid = $realex->getNextOrderId()."-".$timestamp;
	
	// This section of code creates the md5hash that is needed
	$tmp = "$timestamp.$merchantid.$orderid.$amount.$currency.$cardnumber";
	$md5hash = md5($tmp);
	$tmp = "$md5hash.$secret";
	$md5hash = md5($tmp);
	
	// Create and initialise XML parser
	$xml_parser = xml_parser_create();
	xml_set_element_handler($xml_parser, "startElement", "endElement");
	xml_set_character_data_handler($xml_parser, "cDataHandler");
	
	//A number of variables are needed to generate the request xml that is send to Realex Payments.
	$xml = "<request type='auth' timestamp='$timestamp'>
		<merchantid>$merchantid</merchantid>
		<account>$account</account>
		<orderid>$orderid</orderid>
		<amount currency='$currency'>$amount</amount>
		<card> 
			<number>$cardnumber</number>
			<expdate>$expdate</expdate>
			<chname>$cardname</chname> 
			<type>$cardtype</type>
			<issueno>$issueno</issueno>
			<cvn>
				<number>$secure</number>
				<presind>$presind</presind>
			</cvn>		
		</card> 
		<autosettle flag='1'/>
		<comments>
			<comment id='1'></comment>
			<comment id='2'>Prestashop</comment>
		</comments>
		<md5hash>$md5hash</md5hash>
	</request>";
	//echo $xml;exit;
	
	// Send the request array to Realex Payments
	$ch = curl_init();    
	curl_setopt($ch, CURLOPT_URL, "https://epage.payandshop.com/epage-remote.cgi");
	curl_setopt($ch, CURLOPT_POST, 1); 
	curl_setopt($ch, CURLOPT_USERAGENT, "payandshop.com php version 0.9"); 
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
	curl_setopt($ch, CURLOPT_POSTFIELDS, $xml);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE); // this line makes it work under https 
	$response = curl_exec ($ch);     
	curl_close ($ch); 
	
	//Tidy it up
	$response = eregi_replace ( "[[:space:]]+", " ", $response );
	$response = eregi_replace ( "[\n\r]", "", $response );
	
	// parse the response xml
	if (!xml_parse($xml_parser, $response)) {
		 die(sprintf("XML error: %s at line %d",
				  xml_error_string(xml_get_error_code($xml_parser)),
				  xml_get_current_line_number($xml_parser)));
	}
	
	print $TSSChecks["3202"];
	
	// garbage collect the parser.
	xml_parser_free($xml_parser);
	
	//echo $RESPONSE_MESSAGE;
	//echo $RESPONSE_RESULT;
	//exit;

	if ($RESPONSE_RESULT == "00"){
		$customer = new Customer((int)$cart->id_customer);
		if ($cart->id_customer == 0 OR $cart->id_address_delivery == 0 OR $cart->id_address_invoice == 0 OR !$realex->active)
			Tools::redirectLink(__PS_BASE_URI__.'order.php?step=1');	
		$total = floatval($cart->getOrderTotal(true, 3));	
		$retour = $realex->validateOrder($cart->id, _PS_OS_PAYMENT_, $total, $realex->displayName, NULL, NULL,NULL,NULL,$customer->secure_key);		
		$order = new Order($realex->currentOrder);
		Tools::redirectLink(__PS_BASE_URI__.'order-confirmation.php?id_cart='.$cart->id.'&id_module='.$realex->id.'&id_order='.$realex->currentOrder.'&key='.$order->secure_key);
	}
	
	//Else, back to the previous page with error message
	else {	
		if (!$cookie->isLogged(true))
			Tools::redirect('authentication.php?back=order.php');
		
		$realex->errorPaymentNumber = $RESPONSE_RESULT;
		//echo $realex -> errorPaymentNumber;
		//exit;
		$realex->errorPaymentMessage = $RESPONSE_MESSAGE;
		echo $realex->execPayment($cart);		
		include_once(dirname(__FILE__).'/../../footer.php');
	}
}
// else go back to payment page
else {
	echo $realex->execPayment($cart);	
	include_once(dirname(__FILE__).'/../../footer.php');
}

function startElement($parser, $name, $attrs) {
   global $parentElements;
	global $currentElement;
	global $currentTSSCheck;
	
	array_push($parentElements, $name);
	$currentElement = join("_", $parentElements);

	foreach ($attrs as $attr => $value) {
		if ($currentElement == "RESPONSE_TSS_CHECK" and $attr == "ID") {
			$currentTSSCheck = $value;
		}
		$attributeName = $currentElement."_".$attr;
		// print out the attributes..
		//print "$attributeName\n";
		global $$attributeName;
		$$attributeName = $value;
	}
}

function cDataHandler($parser, $cdata) {
	global $currentElement;
	global $currentTSSCheck;
	global $TSSChecks;
	if ( trim ( $cdata ) ) { 
		if ($currentTSSCheck != 0) {
			$TSSChecks["$currentTSSCheck"] = $cdata;
		}
	global $$currentElement;
	$$currentElement .= $cdata;
	}	
}

function endElement($parser, $name) {
   global $parentElements;
	global $currentTSSCheck;
	$currentTSSCheck = 0;
	array_pop($parentElements);
}
?>