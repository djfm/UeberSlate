<?php
/*
This file is part of the Prestashop CardSave Re-Directed Payment Module
See cs_cardsave.php for Licensing and support info.
File Last Modified: 07/12/2010 - By Alistair Richardson - CardSave Online
*/

include(dirname(__FILE__).'/../../config/config.inc.php');
include(dirname(__FILE__) . '/cs_cardsave.php');

if(intval(Configuration::get('PS_REWRITING_SETTINGS')) === 1)
    $rewrited_url = __PS_BASE_URI__;

$cardsave = new cs_cardsave();

// Only allow certain parameters to be passed through
$valid_params = array('cs_checksum', 'cs_payment_amount', 'cs_currency_code', 'cs_merchant_reference', 'cs_email', 'cs_cardholder_name', 'cs_houseno', 'cs_postcode', 'cs_success_url', 'cs_failure_url', 'cs_success_redirect_url', 'cs_failure_redirect_url', 'cs_return_url', 'cs_payment_amount', 'cs_currency_code', 'cs_merchant_reference', 'test');

// Grab the acceptable parameters and filter to prevent XSS
$parameters = array();
foreach ($valid_params as $param_name)
  if (array_key_exists($param_name, $_GET))
    $parameters[$param_name] = htmlspecialchars($_GET[$param_name]);

$cardsave_page = "https://pay.netbanx.com/" . Configuration::get("CS_CARDSAVE_GATEWAYID");

$smarty->assign('form_tag', '<form name="redirectform" method="POST" action="' . $cardsave_page . '">');

// Setup the form for the template
$form_source = '';
foreach ($parameters as $param => $value)
  $form_source .= '<input type="hidden" name="' . $param . '" value="' . $value . '" />';

$smarty->assign('form', $form_source);

$smarty->display(dirname(__FILE__) . '/redirect.tpl');