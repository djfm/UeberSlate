<?php

include("../../config/config.inc.php");

class CatalogExport
{
	protected $path;
	protected $module_name;
	protected $id_lang;
	protected $flag_delim_poid = 'non';
	protected $flag_delim_prix = 'non';

	private $shipping_handling;
	private $shipping_free_price;
	private $shipping_free_weigth;
	private $shipping_method;
	private $shipping_delay;
	private $carrier_default;
	private $country_default;
	private $tax;
	private $data_price;
	private $data_weight;

	private $a_attribute_declination;

	public function __construct()
    {
        $this->module_name	= "jvshopping";

        //Get configuration
        $this->_getIdLangFromGet();
        $this->_getShippingData();
        $this->_getTaxData();
    }

    //id_lang
    private function _getIdLangFromGet()
    {
        if(!empty($_GET['l']))
        {
            $iso_code = mysql_real_escape_string($_GET['l']);
        }
        else
        {
            $iso_code = $this->_getDefaultLanguage();
        }

        $id_lang = $this->_getIdLang($iso_code);

        if(empty($id_lang))
        {
            $id_lang = $this->_getIdLang($this->_getDefaultLanguage());
        }

        $this->id_lang = (int) $id_lang;
    }

    private function _getIdLang($iso_code)
    {
        $query = "
            SELECT id_lang
            FROM "._DB_PREFIX_."lang
            WHERE iso_code = '$iso_code'
        ";

        $language = DbCore::getInstance()->getRow($query);

        return $language["id_lang"];
    }

	public function export()
	{
		//Header
		$header 	= $this->generateHeader();

		$products 	= $this->generateProductList();

		echo $header.$products;
	}

	//////////////////////////////////////
	//			CONFIGURATION			//
	//////////////////////////////////////

	//Get default language
	private function _getDefaultLanguage()
	{
		$query = "
			SELECT L.iso_code
			FROM "._DB_PREFIX_."lang L
			LEFT JOIN "._DB_PREFIX_."configuration C ON L.id_lang = C.value
			WHERE C.name = 'PS_LANG_DEFAULT'
		";

		$languageData 	= DbCore::getInstance()->getRow($query);

		return !empty($languageData["iso_code"]) ? $languageData["iso_code"] : "fr";
	}

	//Get export type
	private function _getExportType()
	{
		$query = "
			SELECT value AS export_type
			FROM "._DB_PREFIX_."configuration
			WHERE name = 'JVSHOPPING_EXPORT_TYPE'
		";

		$exportData = DbCore::getInstance()->getRow($query);

		return !empty($exportData['export_type']) ? $exportData['export_type'] : 'classic';
	}

	//Get export type
	private function _getRewrtitedUrl()
	{
		$query = "
			SELECT value AS rewritten_urls
			FROM "._DB_PREFIX_."configuration
			WHERE name = 'JVSHOPPING_REWRITTEN_URLS'
		";

		$exportData = DbCore::getInstance()->getRow($query);

		if(isset($exportData['rewritten_urls']) AND $exportData['rewritten_urls'] != "on")
		{
			if(!defined("JVSHOPPING_URL_REDIRECT_OFF"))
			{
				define("JVSHOPPING_URL_REDIRECT_OFF",true);
			}
		}
		
		return (isset($exportData['rewritten_urls']) ? $exportData['rewritten_urls'] : '');
	}

	//Shipping Data
	private function _getShippingData()
	{
		$query = '
			SELECT name, value 
			FROM '._DB_PREFIX_.'configuration 
		';

		$a_config = DbCore::getInstance()->ExecuteS($query);

		foreach($a_config as $config)
		{
			if($config['name'] == 'PS_SHIPPING_HANDLING')
				$this->shipping_handling 		= $config['value'];

			if($config['name'] == 'PS_SHIPPING_FREE_PRICE')
				$this->shipping_free_price 		= $config['value'];

			if($config['name'] == 'PS_SHIPPING_FREE_WEIGHT')
				$this->shipping_free_weight 	= $config['value'];

			if($config['name'] == 'PS_SHIPPING_METHOD')
				$this->shipping_method 			= $config['value'];

			if($config['name'] == 'PS_CARRIER_DEFAULT')
				$this->carrier_default 			= (int) $config['value'];

			if($config['name'] == 'PS_COUNTRY_DEFAULT')
				$this->country_default 			= (int) $config['value'];

			if($config['name'] == 'PS_TAX')
				$this->tax 						= $config['value'];
		}

		//Shipping Delay
		$query = "
			SELECT cl.delay FROM "._DB_PREFIX_."carrier_lang cl 
			-- coucou
			WHERE 
				cl.id_lang='{$this->id_lang}' 
					AND 
				cl.id_carrier='{$this->carrier_default}'
		";

		$shipping_delay 		= DbCore::getInstance()->getRow($query);

		$this->shipping_delay 	= $shipping_delay['delay'];
	}

	//Tax
	private function _getTaxData()
	{
		$query_tax = '
			SELECT rate 
			FROM '._DB_PREFIX_.'tax 
			WHERE id_tax='.$this->tax;

		$a_tax 				= DbCore::getInstance()->getRow($query_tax);

		$this->tax 			= $a_tax['rate'];

		$this->data_price 	= array();
		$this->data_weight 	= array();
		
		if($this->shipping_method == 0) //tranche prix
		{
			$query_range_price = "
				SELECT c.id_carrier, rp.delimiter1, rp.delimiter2, t.rate, d.price 
				FROM 		"._DB_PREFIX_."range_price 	rp 
				LEFT JOIN 	"._DB_PREFIX_."carrier 		c 	ON c.id_carrier				= rp.id_carrier 
				LEFT JOIN 	"._DB_PREFIX_."tax_rule 	tr 	ON tr.id_tax_rules_group	= c.id_tax_rules_group 
				LEFT JOIN 	"._DB_PREFIX_."tax 			t 	ON t.id_tax					= tr.id_tax 
				LEFT JOIN 	"._DB_PREFIX_."delivery 	d 	ON rp.id_range_price		= d.id_range_price 
				WHERE 
					rp.id_carrier	= '{$this->carrier_default}' 
						AND
					d.id_zone 		=
					(
						SELECT id_zone 
						FROM "._DB_PREFIX_."country 
						WHERE id_country = '{$this->country_default}'
					) 
				ORDER BY rp.delimiter1
			";


			$a_range_price 	=  DbCore::getInstance()->ExecuteS($query_range_price);

			$cpt 			= 0;
			$numrow 		= count($a_range_price);

			foreach($a_range_price as $range_price)
			{
				$this->data_price[$cpt] = $range_price;

				if (++$cpt == $numrow)
				{
					break;
				}
			}
		}
		else //shipping_method == 1 tranche poid
		{
			$query_range_weight = "
				SELECT c.id_carrier, rw.delimiter1, rw.delimiter2, t.rate, d.price 
				FROM 		"._DB_PREFIX_."range_weight 	rw 
				LEFT JOIN 	"._DB_PREFIX_."carrier 			c 	ON c.id_carrier				= rw.id_carrier 
				LEFT JOIN 	"._DB_PREFIX_."tax_rule 		tr 	ON tr.id_tax_rules_group	= c.id_tax_rules_group 
				LEFT JOIN 	"._DB_PREFIX_."tax 				t 	ON t.id_tax					= tr.id_tax 
				LEFT JOIN 	"._DB_PREFIX_."delivery 		d 	ON rw.id_range_weight		= d.id_range_weight 
				WHERE 
					rw.id_carrier	= '{$this->carrier_default}'
						AND 
					d.id_zone 		=
					(
						SELECT id_zone 
						FROM "._DB_PREFIX_."country 
						WHERE id_country = '{$this->country_default}'
					) 
				ORDER BY rw.delimiter1
			";

			
			$a_range_weight =  DbCore::getInstance()->ExecuteS($query_range_weight);

			$cpt 			= 0;
			$numrow 		= count($a_range_weight);

			if(!empty($a_range_weight))
			{
				foreach($a_range_weight as $range_weight)
				{
					$this->data_price[$cpt] = $range_weight;

					if (++$cpt == $numrow)
					{
						break;
						
					}
				}
			}
		}
	}

	//////////////////////////////////////
	//				HEADER				//
	//////////////////////////////////////

	protected function generateHeader()
	{
		//Basic Header
		$header_basic 		= 'ID_PRODUCT|NAME_PRODUCT|REFERENCE_PRODUCT|SUPPLIER_REFERENCE|MANUFACTURER|CATEGORY|DESCRIPTION|DESCRIPTION_SHORT|PRICE_PRODUCT|DISCOUNT_PRICE|WHOLESALE_PRICE|PRICE_HT|QUANTITY|WEIGHT|EAN|ECOTAX|AVAILABLE_PRODUCT|URL_PRODUCT|IMAGE_PRODUCT|PRODUCT_FEATURE|SHIPPING_FEES|';

		//Product Feature
		$header_feature		= $this->generateFeatureHeader();

		//Product Attributes
		$header_attribute 	= $this->generateAttributeHeader();

		return $header_basic.$header_feature.$header_attribute."\r\n";
	}

	protected function generateFeatureHeader()
	{
		//Product Feature
		$query_feature = "
			SELECT fl.name, fl.id_feature 
			FROM "._DB_PREFIX_."feature_lang fl 
			WHERE fl.id_lang='{$this->id_lang}' 
			ORDER BY fl.id_feature ASC
		";
		
		$a_feature = DbCore::getInstance()->ExecuteS($query_feature);

		$header_feature='';

		if(!empty($a_feature))
		{
			foreach($a_feature as $feature)
			{
				$nom = str_replace(' ', '_', $feature['name']);
				$header_feature .= strtoupper($nom)."|";
			}
		}

		return $header_feature.'PARENT_ID|SHIPPING_DELAY|IMAGE_PRODUCT_2|IMAGE_PRODUCT_3|';
	}

	protected function generateAttributeHeader()
	{
		$header_attribute = '';

		$query_attribute_declination = "
			SELECT DISTINCT(agl.name), agl.id_attribute_group 
			FROM 		"._DB_PREFIX_."product_attribute 				pa 
			LEFT JOIN 	"._DB_PREFIX_."product_attribute_combination 	pac ON pa.id_product_attribute 	= pac.id_product_attribute
			LEFT JOIN 	"._DB_PREFIX_."attribute 						a	ON pac.id_attribute 		= a.id_attribute
			LEFT JOIN 	"._DB_PREFIX_."attribute_lang 					al	ON al.id_attribute 			= pac.id_attribute
			LEFT JOIN 	"._DB_PREFIX_."attribute_group_lang 			agl	ON agl.id_attribute_group 	= a.id_attribute_group
			WHERE 
				al.id_lang 	= '{$this->id_lang}' 
					AND 
				agl.id_lang = '{$this->id_lang}' 
			ORDER BY agl.id_attribute_group ASC
		";
		
		
		$this->a_attribute_declination =  DbCore::getInstance()->ExecuteS($query_attribute_declination);

		if(!empty($this->a_attribute_declination))
		{
			foreach($this->a_attribute_declination as $attribute_declination)
			{
				$name =					str_replace(' ', '_', trim($attribute_declination['name']));
				$header_attribute .=	strtoupper($name)."|";
			}
		}

		return $header_attribute;
	}

	protected function generateProductList()
	{
		//Get the product list_cat_selected_bdd
		$a_products = $this->getProductList();

		return $this->generateProductData($a_products);
	}

	protected function getProductList()
	{
		$query_product	= "
			SELECT 
				p.id_product,
				p.reference 				as product_reference,
				p.supplier_reference, 
				p.ean13,
				p.ecotax,
				p.quantity, 
				pl.id_lang 					as lang, 
				p.price,t.rate as tax,
				p.additional_shipping_cost,
				p.wholesale_price,
				p.id_category_default 		as category_id, 
				p.price, 
				p.wholesale_price, 
				p.id_category_default 		as category_id, 
				pl.description,
				pl.description_short,
				pl.name,
				pl.available_now,
				p.weight,
				m.name 						as manufacturer,
			(
				SELECT pi.id_image 
				FROM "._DB_PREFIX_."image pi 
				WHERE 
					pi.id_product	= p.id_product 
						AND 
					pi.cover		= 1 
					LIMIT 1
			) as id_image,
			(
				SELECT cl.name 
				FROM "._DB_PREFIX_."category_lang cl 
				INNER JOIN "._DB_PREFIX_."category_product cp ON cp.id_category = cl.id_category 
				WHERE 
					cl.id_lang		= '{$this->id_lang}' 
						AND 
					cp.id_product	= p.id_product 
				ORDER BY cp.position ASC 
				LIMIT 1
			) as category
			
			FROM 		"._DB_PREFIX_."product 				p 
			LEFT JOIN 	"._DB_PREFIX_."product_lang 		pl 	ON p.id_product=pl.id_product 
			LEFT JOIN 	"._DB_PREFIX_."product_attribute 	pa 	ON p.id_product=pa.id_product 
			LEFT JOIN 	"._DB_PREFIX_."manufacturer 		m 	ON m.id_manufacturer=p.id_manufacturer 
			LEFT JOIN 	"._DB_PREFIX_."tax_rule 			tr	ON tr.id_tax_rules_group=p.id_tax_rules_group 
			LEFT JOIN 	"._DB_PREFIX_."tax 					t 	ON t.id_tax=tr.id_tax 
			WHERE 
				pl.id_lang	= '{$this->id_lang}' 
					AND 
				p.active	= 1 
			GROUP BY p.id_product
		";

		
		return DbCore::getInstance()->ExecuteS($query_product);
	}


	protected function generateProductData(&$a_products)
	{
		$product_data = '';

		$this->_getRewrtitedUrl();
		
		if(!empty($a_products))
		{
			foreach($a_products as $product)
			{
				//id_product
				$id_product 		= $product['id_product'];

				//Description
				$description 		= ($product['description']);
				$description 		= $this->_cleanHtml(nl2br($description));

				//Description short
				$description_short 	= ($product['description_short']);
				$description_short 	= $this->_cleanHtml(nl2br($description_short));

				//Category
				$category 			= $this->_getParentCategory($product['category_id']);

				//Name
				$name 				= $product['name'];

				//Available
				$available_now 		= $product['available_now'];

				//Ecotax
				$ecotax 			= $product['ecotax'];

				//EAN
				$ean13 				= $product['ean13'];

				//Reference
				$reference 			= $product['product_reference'];
				$reference 			= $this->_cleanHtml(str_replace('-', '', $reference));

				//Supplier Reference
				$supplier_reference = $product['supplier_reference'];
				$supplier_reference = $this->_cleanHtml(str_replace('-', '', $supplier_reference));

				//Quantity
				$quantity 			= $product['quantity'];

				//Manufacturer
				$manufacturer 		= $product['manufacturer'];

				//Price TTC
				$price 				= $product['price'] + ($product['price'] * $product['tax']/100);
				$price 				= number_format(round($price, 2),2, '.', '');

				//Discount price
				$discount_price 	= $this->_getDiscountPrice($product["id_product"], $product['price']);
				$discount_price 	= $discount_price + ($discount_price * $product['tax'] / 100);
				$discount_price 	= number_format(round($discount_price,2),2, '.', '');

				//Wholesale_price
				$wholesale_price 	= number_format(round($product['wholesale_price'],2),2, '.', '');

				//Price
				$price_HT 			= number_format(round($product['price'],2),2, '.', '');

				//Weight
				$weight 			= ($product['weight']);

				//Destination URL
				$url = 'http://'.$_SERVER['HTTP_HOST'].constant('__PS_BASE_URI__').'product.php?id_product='.$product['id_product'];

				$url = $this->getrUrlRdirect($url);
				
				//URL image
				if($product['id_image'] > 0 or !empty($product['id_image']))
				{
					$image = 'http://'.$_SERVER['HTTP_HOST'].constant('__PS_BASE_URI__').'img/p/'.$product['id_product'].'-'.$product['id_image'].'-large.jpg';
				}
				else
				{
					$image = '';
				}

				//Product feature
				$a_product_feature = array();

				$query_product_feature = "SELECT fl.name, fl.id_feature FROM "._DB_PREFIX_."feature_lang fl WHERE fl.id_lang='{$this->id_lang}' ORDER BY fl.id_feature ASC ";

				$a_product_feature = DbCore::getInstance()->ExecuteS($query_product_feature);

				$product_feature = "";
				foreach($a_product_feature as $productFeature)
				{
					$id_feature = $productFeature['id_feature'];

					$a_values = array();

					$query = "
						SELECT fp.id_feature_value,fvl.value
						FROM 		"._DB_PREFIX_."feature_product 		fp
						LEFT JOIN 	"._DB_PREFIX_."feature_value_lang 	fvl 	ON 	fp.id_feature_value = fvl.id_feature_value
						WHERE
							fp.id_feature='$id_feature' 
								AND 
							id_product='".$product["id_product"]."'
								AND 
							fvl.id_lang='{$this->id_lang}'
					";

					$a_values = DbCore::getInstance()->ExecuteS($query);

					if(count($a_values) > 0)
					{
						$product_feature .= $a_values[0]['value'].'|';
					}
					else
					{
						$product_feature .= ''.'|';
					}
				}

				if($this->shipping_method == 0) //Price
				{
					$shipping_fees = $this->shippingFeesPrice
					(
						$this->shipping_method, 
						$this->data_price, 
						$price, 
						$this->shipping_handling, 
						$this->shipping_free_price, 
						$this->tax
					);
				}
				else //Weight
				{
					$shipping_fees = $this->shippingFeesWeight
					(
						$this->shipping_method, 
						$this->data_weight, 
						$weight, $this->shipping_handling, 
						$this->shipping_free_weight, 
						$this->tax
					);
				}

				$shipping_fees += $product['additional_shipping_cost'];

				//Images
				$query_images = '
					SELECT pi.id_image 
					FROM '._DB_PREFIX_.'image pi 
					WHERE 
						pi.id_product='.$product['id_product'].' 
							AND 
						pi.cover<>1 LIMIT 2
				';

				$a_images = DbCore::getInstance()->ExecuteS($query_images);


				if(count($a_images) > 0)
				{
					if($a_images[0]['id_image'] > 0 or !empty($a_images[0]['id_image']))
					{
						$image2 = 'http://'.$_SERVER['HTTP_HOST'].constant('__PS_BASE_URI__').'img/p/'.$product['id_product'].'-'.$a_images[0]['id_image'].'-large.jpg';
					}
					else
					{
						$image2 = '';
					}
					
					if($a_images[1]['id_image'] > 0 or !empty($a_images[1]['id_image']))
					{
						$image3 = 'http://'.$_SERVER['HTTP_HOST'].constant('__PS_BASE_URI__').'img/p/'.$product['id_product'].'-'.$a_images[1]['id_image'].'-large.jpg';
					}
					else
					{
						$image3 = '';
					}
				}
				else
				{
					$image2 = '';
					$image3 = '';
				}

				//Product Attribute
				$product_attibute ='';
				foreach($this->a_attribute_declination as $attribute_declination)
				{
					$product_attibute .= ''.'|';
				}

				//Add product data if the price isn't null
				if($product['price'] != 0)
				{
					$product_data .= $id_product.'|'.$name.'|'.$reference.'|'.$supplier_reference.'|'.$manufacturer.'|'.$category.'|'.$description.'|'.$description_short.'|'.$price.'|'.$discount_price.'|'.$wholesale_price.'|'.$price_HT.'|'.$quantity.'|'.$weight.'|'.$ean13.'|'.$ecotax.'|'.$available_now.'|'.$url.'|'.$image.'||'.$shipping_fees.'|'.$product_feature.$id_product.'|'.$this->shipping_delay.'|'.$image2.'|'.$image3.'|'.$product_attibute."\r\n";
				}
			}

			if($this->_getExportType() == 'full')
			{
				$query_declination_produit = "
					SELECT DISTINCT 
						pa.id_product_attribute,
						p.id_product,
						p.reference as product_reference,
						pa.reference as product_reference_declinaison,
						p.supplier_reference,
						pa.supplier_reference as supplier_reference_declinaison,
						p.ean13,
						pa.ean13 as ean13_declinaison , 
						pa.ecotax, 
						pa.quantity, 
						pl.id_lang as lang, 
						p.price as price,
						t.rate as tax,
						p.additional_shipping_cost,
						pa.price as price_attribute,
						pa.wholesale_price, 
						p.id_category_default as category_id, 
						pl.description,
						pl.description_short,
						pl.name,
						pl.available_now,
						p.weight, 
						pa.weight as poid_declinaison,
						m.name as manufacturer,
						(
							SELECT pi.id_image 
							FROM "._DB_PREFIX_."image pi 
							WHERE 
								pi.id_product=p.id_product 
									AND 
									pi.cover=1
							LIMIT 1
						) as id_image,
						(
							SELECT pai.id_image 
							FROM "._DB_PREFIX_."product_attribute_image pai 
							WHERE pai.id_product_attribute = pa.id_product_attribute 
							LIMIT 1
						)	as id_image2,
						(
							SELECT cl.name 
							FROM "._DB_PREFIX_."category_lang 
							cl INNER JOIN "._DB_PREFIX_."category_product cp ON cp.id_category = cl.id_category 
							WHERE 
								cl.id_lang='{$this->id_lang}' 
									AND 
								cp.id_product=p.id_product 
							ORDER BY cp.position ASC LIMIT 1
						) as category 
						FROM 		"._DB_PREFIX_."product 				p 
						LEFT JOIN 	"._DB_PREFIX_."product_lang 		pl	ON p.id_product				= pl.id_product 
						LEFT JOIN 	"._DB_PREFIX_."product_attribute 	pa	ON p.id_product				= pa.id_product 
						LEFT JOIN 	"._DB_PREFIX_."manufacturer 		m 	ON m.id_manufacturer 		= p.id_manufacturer 
						LEFT JOIN 	"._DB_PREFIX_."tax_rule 			tr 	ON tr.id_tax_rules_group 	= p.id_tax_rules_group 
						LEFT JOIN 	"._DB_PREFIX_."tax 					t	ON t.id_tax 				= tr.id_tax 
						WHERE 
							pl.id_lang='{$this->id_lang}' 
								AND 
							p.active=1 
					";

				
				$a_declination =  DbCore::getInstance()->ExecuteS($query_declination_produit);

				// BOUCLE DECLINAISONS PRODUITS
				foreach($a_declination as $product)
				{
					//id_product
					$id_product 		= $product['id_product']."_".$product['id_product_attribute'];

					//Description
					$description 		= $this->_cleanHtml(nl2br($product['description']));

					//Description short
					$description_short 	= $this->_cleanHtml(nl2br($product['description_short']));
					$description_short 	= $description_short;

					//Category
					$category 			= $this->_getParentCategory($product['category_id']);

					//Name

					$query_feature_declination = "
						SELECT agl.name, al.name AS valeur 
						FROM 		"._DB_PREFIX_."product_attribute 				pa 
						LEFT JOIN 	"._DB_PREFIX_."product_attribute_combination 	pac ON pa.id_product_attribute 		= pac.id_product_attribute
						LEFT JOIN 	"._DB_PREFIX_."attribute 						a 	ON pac.id_attribute 			= a.id_attribute
						LEFT JOIN 	"._DB_PREFIX_."attribute_lang 					al 	ON al.id_attribute 				= pac.id_attribute
						LEFT JOIN 	"._DB_PREFIX_."attribute_group_lang 			agl ON agl.id_attribute_group 		= a.id_attribute_group
						WHERE 
							al.id_lang ='{$this->id_lang}' 
								AND 
							agl.id_lang ='{$this->id_lang}' 
								AND 
							pa.id_product_attribute ='".$product["id_product_attribute"]."'
					";

					$a_feature_declination =  DbCore::getInstance()->ExecuteS($query_feature_declination);

					if(!empty($product['id_product_attribute']))
					{
						$feature_declination =" ";
						
						foreach($a_feature_declination as $product_feature_declination)
						{
							$feature_declination .= $feature_declination['name'].' '.$feature_declination['valeur'].' ';
						}
						
						$feature_declination = rtrim($feature_declination);
						
						$name 		= $product['name'].$feature_declination;
					}
					else
					{
						$name 		= $product['name'];
					}

					//Available
					$available_now 	= $product['available_now'];

					// Ecotax
					$ecotax 		= $product['ecotax'];

					// EAN
					if($product['ean13_declinaison'] !="")
					{
						$ean13 		= $product['ean13_declinaison'];
					}
					else
					{
						$ean13 		= $product['ean13'];
					}

					//Reference
					if($product['product_reference_declinaison'] !="")
					{
						$reference 	= ($product['product_reference_declinaison']);
					}
					else
					{
						$reference 	= ($product['product_reference']);
					}

					//Supplier Reference
					if($product['supplier_reference_declinaison'] !="")
					{
						$supplier_reference = $product['supplier_reference_declinaison'];
					}
					else
					{
						$supplier_reference = $product['supplier_reference'];
					}

					//Quantity
					$quantity 		= $product['quantity'];

					//Manufacturer
					$manufacturer 	= $product['manufacturer'];

					//Price
					$price_tmp 			= $product['price'] + $product['price_attribute'];
					$price 				= $price_tmp + ($price_tmp * $product['tax'] / 100);
					$price 				= number_format(round($price, 2),2, '.', '');

					//Discount price
					$discount_price 	= $this->_getDiscountPrice($product["id_product"], $price_tmp);
					$discount_price 	= $discount_price + ($discount_price * $product['tax'] / 100);
					$discount_price 	= number_format(round($discount_price,2),2, '.', '');

					//Wholesale_price
					$wholesale_price 	= number_format(round($product['wholesale_price'],2),2, '.', '');

					//Price
					$price_HT 			= number_format(round($price_tmp,2),2, '.', '');


					//Weight
					$weight 			= $product['weight'] + $product['poid_declinaison'];

					//URL destination
					$url = 'http://'.$_SERVER['HTTP_HOST'].constant('__PS_BASE_URI__').'product.php?id_product='.$product['id_product'];
				
					$url = $this->getrUrlRdirect($url);
					

					//URL image
					if($product['id_image'] > 0 || !empty($product['id_image']))
					{
						if($product['id_image2'] > 0 || !empty($product['id_image2']))
						{
							$image = 'http://'.$_SERVER['HTTP_HOST'].constant('__PS_BASE_URI__').'img/p/'.$product['id_product'].'-'.$product['id_image2'].'-large.jpg';
						}
						else
						{
							$image = 'http://'.$_SERVER['HTTP_HOST'].constant('__PS_BASE_URI__').'img/p/'.$product['id_product'].'-'.$product['id_image'].'-large.jpg';
						}
					}
					else
					{
						$image = '';
					}

					//Product feature
					$query_product_feature = "
						SELECT fl.name, fl.id_feature 
						FROM "._DB_PREFIX_."feature_lang fl 
						WHERE fl.id_lang='{$this->id_lang}' 
						ORDER BY fl.id_feature ASC 
					";

					$a_product_feature =  DbCore::getInstance()->ExecuteS($query_product_feature);

					$product_feature = "";
					foreach($a_product_feature as $productFeature)
					{
						$id_feature = $productFeature['id_feature'];

						$a_values = array();

						$query = "
						SELECT fp.id_feature_value,fvl.value
							FROM "._DB_PREFIX_."feature_product fp
							LEFT JOIN "._DB_PREFIX_."feature_value_lang fvl ON fp.id_feature_value = fvl.id_feature_value
							WHERE
								fp.id_feature=".$id_feature." 
									AND 
								id_product='".$product["id_product"]."'
									AND 
								fvl.id_lang='{$this->id_lang}'
						";

						$a_values = DbCore::getInstance()->ExecuteS($query);

						if(count($a_values)>0)
						{
							$product_feature .= $a_values[0]['value'].'|';
						}
						else
						{
							$product_feature .= ''.'|';
						}
					}

					if($this->shipping_method == 0) //tranche prix
					{
						$shipping_fees = $this->shippingFeesPrice
						(
							$this->shipping_method, 
							$this->data_price, 
							$price, 
							$this->shipping_handling, 
							$this->shipping_free_price, 
							$this->tax
						);
					}
					else // tranche poid
					{
						$shipping_fees = $this->shippingFeesWeight
						(
							$this->shipping_method, 
							$this->data_weight, 
							$weight, 
							$this->shipping_handling, 
							$this->shipping_free_weight, 
							$this->tax
						);
					}

					$shipping_fees += $product["additional_shipping_cost"];

					//IMAGES SUPPLEMENTAIRE
					$query_image = '
						SELECT pi.id_image 
						FROM '._DB_PREFIX_.'image pi 
							WHERE pi.id_product='.$product['id_product'].' 
								AND 
							pi.cover<>1 LIMIT 2
					';

					$a_image = DbCore::getInstance()->ExecuteS($query_image);

					if(count($a_image) > 0)
					{
						if($a_image[0]['id_image'] > 0 or !empty($a_image[0]['id_image']))
						{
							$image2 = 'http://'.$_SERVER['HTTP_HOST'].constant('__PS_BASE_URI__').'img/p/'.$product['id_product'].'-'.$a_image[0]['id_image'].'-large.jpg';
						}
						else
						{
							$image2 = '';
						}
						if($a_image[1]['id_image'] > 0 or !empty($a_image[1]['id_image']))
						{
							$image3 = 'http://'.$_SERVER['HTTP_HOST'].constant('__PS_BASE_URI__').'img/p/'.$product['id_product'].'-'.$a_image[1]['id_image'].'-large.jpg';
						}
						else
						{
							$image3 = '';
						}
					}
					else
					{
						$image2 = '';
						$image3 = '';
					}

					//Product Attribute
					$product_attibute = '';
					if($product['id_product_attribute'] != '')
					{
						foreach($this->a_attribute_declination as $attribute)
						{
							$a_product_attribute = array();

							$query_product_attribute_declination = "
								SELECT agl.name, al.name AS valeur 
								FROM 		"._DB_PREFIX_."product_attribute 				pa 
								LEFT JOIN 	"._DB_PREFIX_."product_attribute_combination 	pac ON pa.id_product_attribute 	= pac.id_product_attribute
								LEFT JOIN 	"._DB_PREFIX_."attribute 						a 	ON pac.id_attribute 		= a.id_attribute
								LEFT JOIN 	"._DB_PREFIX_."attribute_lang 					al 	ON al.id_attribute 			= pac.id_attribute
								LEFT JOIN 	"._DB_PREFIX_."attribute_group_lang 			agl ON agl.id_attribute_group 	= a.id_attribute_group
								WHERE 
									al.id_lang 				='{$this->id_lang}' 
										AND 
									agl.id_lang 			='{$this->id_lang}' 
										AND 
									pa.id_product_attribute =".$product["id_product_attribute"]."
										AND 
									agl.id_attribute_group	=".$attribute["id_attribute_group"]."
								";

							$a_product_attribute =  DbCore::getInstance()->ExecuteS($query_product_attribute_declination);

							if(!empty($a_product_attribute))
							{
								$a_product_attribute = $a_product_attribute[0];
							}

							if(count($a_product_attribute>0) && !empty($a_product_attribute))
							{
								$product_attibute .= $a_product_attribute['valeur'].'|';
							}
							else
							{
								$product_attibute .= ''.'|';
							}
						}
					}

					// INSERTION DE LA LIGNE PRODUIT
					if($product['id_product_attribute'] != NULL)
					{
						$product_data .= $id_product.'|'.$name.'|'.$reference.'|'.$supplier_reference.'|'.$manufacturer.'|'.$category.'|'.$description.'|'.$description_short.'|'.$price.'|'.$discount_price.'|'.$wholesale_price.'|'.$price_HT.'|'.$quantity.'|'.$weight.'|'.$ean13.'|'.$ecotax.'|'.$available_now.'|'.$url.'|'.$image.'||'.$shipping_fees.'|'.$product_feature.$product['id_product'].'|'.$this->shipping_delay.'|'.$image2.'|'.$image3.'|'.$product_attibute."\r\n";
					}
				}
			}
		}

		return $product_data;
	}

	private function _getDiscountPrice($productId, $defaultPrice)
	{
		$query_reduction  = "
			SELECT sp.price, sp.reduction, sp.reduction_type 
			FROM "._DB_PREFIX_."specific_price sp 
			WHERE 
				sp.id_product='$productId'
					AND 
				(sp.from ='0000-00-00 00:00:00' OR sp.from 	<= '".date("Y-m-d H:i:s")."') 
					AND 
				(sp.to	 ='0000-00-00 00:00:00' OR sp.to 	>= '".date("Y-m-d H:i:s")."') 
		";

		$priceReductionData = DbCore::getInstance()->getRow($query_reduction);

		$price = $priceReductionData['price'] > 0 ? $priceReductionData['price'] : $defaultPrice;
		$reduction = $priceReductionData['reduction'];
		$reduction_type = $priceReductionData['reduction_type'];

		$new_price = $price;

		if($reduction_type == 'amount')
		{
			$new_price = $price - $reduction;
		}
		elseif($reduction_type == 'percentage')
		{
			$new_price = $price - $price * $reduction;
		}

		return $new_price;
	}

	private function _getParentCategory($categoryId, $categoryName='')
	{
		if($categoryName =='')
		{
			$categoryName = $this->_getCategoryName($categoryId);
		}
		else
		{
			$categoryName = $this->_getCategoryName($categoryId).' > '.$categoryName;
		}

		$query_category_parent = "SELECT id_parent FROM "._DB_PREFIX_."category  WHERE id_category='$categoryId'";

		$a_category_parent = DbCore::getInstance()->ExecuteS($query_category_parent);

		if(isset($a_category_parent) && ($a_category_parent[0]['id_parent'] !=0))
		{
			$categoryName = $this->_getParentCategory($a_category_parent[0]['id_parent'], $categoryName);
		}

		return $categoryName;
	}

	function _getCategoryName($categoryId)
	{
		$query_category_name = "
			SELECT cl.name  as category_name 
			FROM ".constant("_DB_PREFIX_")."category_lang cl 
			WHERE 
				cl.id_lang='{$this->id_lang}' 
					AND 
				cl.id_category='$categoryId'
		";

		$a_category = DbCore::getInstance()->ExecuteS($query_category_name);

		$category_name = $a_category[0]['category_name'];
		$category_name = preg_replace("`^[0-9]*`",'',$category_name);
		$category_name = preg_replace("`^[-.]*`",'',$category_name);
		$category_name = trim($category_name);

		return $category_name;
	}

	private function shippingFeesPrice($mode, $data, $price, $frais_manut, $free_prix, $tax_conf)
	{
		$shipping_fees = 0;
		if(isset($data[0]['delimiter1']))
		{
			foreach($data as $info)
			{
				if($price >= round($info['delimiter1'],0) && $price < $info['delimiter2'])
				{
					if($price<=$free_prix)
					{
						if($info['rate']!='')
						{
							$taux_tva =$info['rate'];
						}
						else
						{
							$taux_tva =$tax_conf;
						}
						$shipping_fees_HT 	= $info['price']+$frais_manut;
						$tva 				= ($shipping_fees_HT*$taux_tva)/100;
						$shipping_fees 		= $shipping_fees_HT+$tva;
						$shipping_fees 		= round($shipping_fees, 2);

						return $shipping_fees;
					}
					else
					{
						$shipping_fees = 0;

						return $shipping_fees;
					}
				}
			}
		}
		else
		{
			if($price<=$free_prix)
			{
				$shipping_fees_HT 	= $frais_manut;
				$tva 				= ($shipping_fees_HT*$tax_conf)/100;
				$shipping_fees 		= $shipping_fees_HT+$tva;
				$shipping_fees 		= round($shipping_fees, 2);

				return $shipping_fees;
			}
			else
			{
				$shipping_fees 		= 0;

				return $shipping_fees;
			}
		}
		return $shipping_fees;
	}

	private function shippingFeesWeight($mode, $data, $weight, $frais_manut, $free_poid, $tax_conf)
	{
		if(isset($data[0]['delimiter1']))
		{
			foreach($data as $info)
			{
				if($weight >= round($info['delimiter1'],0) && $weight < $info['delimiter2'])
				{
					if($weight<=$free_poid)
					{
						if($info['rate']!='')
						{
							$taux_tva = $info['rate'];
						}
						else
						{
							$taux_tva = $tax_conf;
						}
						$shipping_fees_HT 	= $info['price']+$frais_manut;
						$tva 				= ($shipping_fees_HT*$taux_tva)/100;
						$shipping_fees 		= $shipping_fees_HT+$tva;
						$shipping_fees 		= round($shipping_fees, 2);
						return $shipping_fees;
					}
					else
					{
						$shipping_fees 		= 0;
						
						return $shipping_fees;
					}
				}
			}
		}
		else
		{
			if($weight<=$free_poid)
			{
				$shipping_fees_HT 			= $frais_manut;
				$tva 						= ($shipping_fees_HT*$tax_conf)/100;
				$shipping_fees 				= $shipping_fees_HT+$tva;
				$shipping_fees 				= round($shipping_fees, 2);
				
				return $shipping_fees;
			}
			else
			{
				$shipping_fees 				= 0;
				
				return $shipping_fees;
			}
		}
		return $shipping_fees;
	}

	private function _cleanHtml($string)
	{
		$string = strip_tags ($string);
		$string = trim ($string);
		$string = str_replace("&nbsp;"," ",$string);
		$string = str_replace("|"," ",$string);
		$string = str_replace("&#39;","' ",$string);
		$string = str_replace("&#150;","-",$string);
		$string = str_replace(chr(9)," ",$string);
		$string = str_replace(chr(10)," ",$string);
		$string = str_replace(chr(13)," ",$string);

		return $string;
	}
	
	private function getrUrlRdirect($url)
	{
		if(!defined("JVSHOPPING_URL_REDIRECT_OFF"))
		{
			$curl = curl_init();
			curl_setopt($curl, 	CURLOPT_URL, 			$url);
			curl_setopt($curl, 	CURLOPT_HEADER, 		true);
			curl_setopt($curl, 	CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($curl,	CURLOPT_FOLLOWLOCATION,	0);
			$result = curl_exec($curl);
			curl_close($curl);
			
			$a_result = explode("\n",$result);
			
			$url_new = "";
			
			if(count($a_result))
			foreach($a_result as $v)
			{
				if(preg_match("%^Location: (http.*)%",$v,$a_res))
				{
					$url_new = $a_res[1];
				}
			}
			
			if($url_new == $url OR $url_new == "")
			{
				define("JVSHOPPING_URL_REDIRECT_OFF",true);
			}
			
			if($url_new != "")
			{
				$url = $url_new;
				
			}
		}
		
		return $url;
	}
}
