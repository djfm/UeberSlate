{literal}
	<script type="text/javascript">
		$(document).ready(function(){
			var selectcard = $('#cardtype option[selected]').val();
			if (selectcard=="AMEX" || selectcard=="VISA" || selectcard=="MC" || !selectcard)
				$('.ccv').show();
			else {
				$('.ccv').hide();
				$('input#secure').val("");
			}
			if (selectcard == "SWITCH")
				$('.issueno').show();
			else {
				$('.issueno').hide();
				$('input#issue').val("");
			}			
	
			$('#cardtype').change(function() {
				var cardtype =$('#cardtype').val();
				if (cardtype == "AMEX" || cardtype == "VISA" || cardtype == "MC")
					$('.ccv').fadeIn();
				else {
					$('.ccv').fadeOut();
					$('input#secure').val("");
				}
				if (cardtype == "UKDM"){
					$('.issueno').fadeIn();
					}
				else {
					$('.issueno').fadeOut();
					$('input#issue').val("");
				}			
			});
		})
	</script>
{/literal}